package projectsdl;

import java.util.Scanner;

public class ProjectSDL {

    static Reservasi r;

    public static void main(String[] args) {
        String n, nomor, tgl, batal;
        int nip, cr;
        Reservasi r1;
        Antrian antrian = new Antrian();

        System.out.println("-----------------------------");
        System.out.println("PROGRAM RESERVASI RESTAURANT");
        System.out.println("-----------------------------");
        System.out.println("Selamat Datang!");
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Reservasi");
        System.out.println("2. Sudah Dilayani");
        System.out.println("3. Lihat Daftar");
        System.out.println("4. Cari NIK");
        System.out.println("5. Keluar");

        int a = 0;
        while (a != 5) {
            System.out.print("Pilih Menu : ");
            a = sc.nextInt();
            switch (a) {
                case 1:
                    r = new Reservasi();
                    System.out.print("Masukan Nama : ");
                    n = sc.next();
                    System.out.print("Masukan NIK : ");
                    nip = sc.nextInt();
                    System.out.print("Masukan Nomor Telp : ");
                    nomor = sc.next();
                    System.out.print("Masukan Tanggal Reservasi : ");
                    tgl = sc.next();
                    r.setNama(n);
                    r.setNip(nip);
                    r.setNomor(nomor);
                    r.setTanggal(tgl);
                    antrian.enqueue(r);
                    break;
                case 2:
                    System.out.println("Apakah Anda sudah dilayani?");
                    System.out.println("1. Yes                  2.No");
                    System.out.print("Jawab : ");
                    batal = sc.next();
                    try {
                        if (batal.equals("1")) {
                            antrian.dequeue();
                            break;
                        } else {
                            System.out.println("Terimakasih");
                            break;
                        }
                    } catch (Exception e) {
                        System.err.printf("Exception : %s\n", e);
                        System.out.println("Reservasi kosong");
                    }
                    break;
                case 3:
                    System.out.println("Daftar Orang yang Mereserve");
                    antrian.cetak();
                    break;
                case 4:
                    System.out.print("Data yang dicari : ");
                    cr = sc.nextInt();
                    Object cari = new Reservasi(cr);
                    ListNodeOb b = antrian.search(cari);
                    if (b != null) {
                        System.out.println("Data " + b.getElemen());
                    } else {
                        System.out.println("Data yang dicari tidak ada");
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
