package projectsdl;

public class ListNodeOb {

    Object elemen;
    ListNodeOb next;
    ListNodeOb prev;

    public ListNodeOb() {
        next = null;
        prev = null;
    }

    public ListNodeOb(Object x) {
        elemen = x;
        next = null;
        prev = null;
    }

    public Object getElemen() {
        return elemen;
    }

    public void setElemen(Object elemen) {
        this.elemen = elemen;
    }

    public ListNodeOb getNext() {
        return next;
    }

    public void setNext(ListNodeOb next) {
        this.next = next;
    }

    public ListNodeOb getPrev() {
        return prev;
    }

    public void setPrev(ListNodeOb prev) {
        this.prev = prev;
    }
}
