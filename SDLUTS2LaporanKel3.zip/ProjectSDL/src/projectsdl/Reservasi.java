package projectsdl;

public class Reservasi implements Comparable {

    private String nama;
    private int nik;
    private String nomor;
    private String tanggal;

    public Reservasi() {
    }

    public Reservasi(int nik) {
        this.nik = nik;
    }

    public Reservasi(String nama, int nik, String nomor, String tanggal) {
        this.nama = nama;
        this.nik = nik;
        this.nomor = nomor;
        this.tanggal = tanggal;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getNip() {
        return nik;
    }

    public void setNip(int nik) {
        this.nik = nik;
    }

    public String getNomor() {
        return nomor;
    }

    public void setNomor(String nomor) {
        this.nomor = nomor;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    @Override
    public String toString() {
        return "\nNama\t= " + nama + "\nNIK\t= " + nik + "\nNomor\t= " + nomor
                + "\nTanggal\t= " + tanggal;
    }

    @Override
    public int compareTo(Object o) {
        if (nik == ((Reservasi) o).getNip()) {
            return 0;
        } else if (nik < ((Reservasi) o).getNip()) {
            return -1;
        } else {
            return 1;
        }
    }
}
