package projectsdl;

import java.util.NoSuchElementException;

public class LinkedListOb {

    private ListNodeOb head;
    private int size;

    public LinkedListOb() {
        head = new ListNodeOb();
        head.next = head;
        head.prev = head;
        size = 0;
    }

    public ListNodeOb addBefore(Object x, ListNodeOb bantu) {
        ListNodeOb baru = new ListNodeOb(x);
        baru.next = bantu;
        baru.prev = bantu.prev;
        bantu.prev.next = baru;
        bantu.prev = baru;
        size++;
        return baru;

    }

    public void addFirst(Object x) {
        addBefore(x, head.next);
    }

    public void addLast(Object x) {
        addBefore(x, head);
    }

    public Object remove(ListNodeOb bantu) {
        if (isEmpty()) {
            throw new NoSuchElementException();
        } else {
            bantu.prev.next = bantu.next;
            bantu.next.prev = bantu.prev;
            bantu.next = null;
            bantu.prev = null;
            size--;
            return bantu.elemen;
        }
    }

    public Object removeFirst() {
        return remove(head.next);
    }

    public Object removeLast() {
        return remove(head.prev);
    }

    public boolean isEmpty() {
        if (head.next == head) {
            return true;
        } else {
            return false;
        }
    }

    public void print() {
        ListNodeOb bantu = head.next;
        while (bantu != head) {
            System.out.println(bantu.elemen + " ");
            bantu = bantu.next;
        }

    }

    public ListNodeOb search(Object x) {
        ListNodeOb baru = head.next;
        while (baru != head) {
            if (((Comparable) baru.elemen).compareTo(x) == 0) {
                return baru;
            }
            baru = baru.next;
        }
        return null;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
