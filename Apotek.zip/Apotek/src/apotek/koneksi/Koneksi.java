package apotek.koneksi;

import java.sql.*;
import javax.swing.*;
import apotek.frame.*;

public class Koneksi {

    FormLogin m;

    public Connection getConnection() {
        String host = "localhost";
        String port = "1521";
        String db = "xe";
        String user = "hr";
        String password = "hr";
        Connection conn = null;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(m, "Driver tidak ditemukan");
            JOptionPane.showMessageDialog(m, e.getMessage());
        }

        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":"
                    + port + ":" + db, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(m, "Koneksi gagal");
            JOptionPane.showMessageDialog(m, e.getMessage());
        }

        if (conn == null) {
            JOptionPane.showMessageDialog(m, "Koneksi gagal");
        }
        return conn;
    }
}
