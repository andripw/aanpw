package apotek.data;

import java.util.ArrayList;

public class Nota {

    private ArrayList<Transaksi> daftarTransaksi = new ArrayList();

    public Nota() {
    }

    public void tambahTransaksi(Transaksi transaksi) {
        getDaftarTransaksi().add(transaksi);
    }

    public ArrayList<Transaksi> getDaftarTransaksi() {
        return daftarTransaksi;
    }

    public void setDaftarTransaksi(ArrayList<Transaksi> daftarTransaksi) {
        this.daftarTransaksi = daftarTransaksi;
    }

    @Override
    public String toString() {
        String hasil = new String();
        for (int i = 0; i < daftarTransaksi.size(); i++) {
            hasil = hasil + daftarTransaksi.get(i).toString() + "\n";
        }
        return hasil;
    }
}
