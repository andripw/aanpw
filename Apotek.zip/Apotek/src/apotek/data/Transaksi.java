package apotek.data;

public class Transaksi {

    private String kodeBarang;
    private String namaBarang;
    private int jumlah;
    private int hargaBarang;
    private int totalHarga;
    private int bayar;
    private int kembalian;

    public Transaksi() {
    }

    public Transaksi(String kodeBarang, String namaBarang, int jumlah, int hargaBarang, int totalHarga, int bayar, int kembalian) {
        this.kodeBarang = kodeBarang;
        this.namaBarang = namaBarang;
        this.jumlah = jumlah;
        this.hargaBarang = hargaBarang;
        this.totalHarga = totalHarga;
        this.bayar = bayar;
        this.kembalian = kembalian;
    }

    public int getBayar() {
        return bayar;
    }

    public void setBayar(int bayar) {
        this.bayar = bayar;
    }

    public int getKembalian() {
        return kembalian;
    }

    public void setKembalian(int kembalian) {
        this.kembalian = kembalian;
    }

    public String getKodeBarang() {
        return kodeBarang;
    }

    public void setKodeBarang(String kodeBarang) {
        this.kodeBarang = kodeBarang;
    }

    public int getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(int totalHarga) {
        this.totalHarga = totalHarga;
    }  

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public int getHargaBarang() {
        return hargaBarang;
    }

    public void setHargaBarang(int hargaBarang) {
        this.hargaBarang = hargaBarang;
    }

    @Override
    public String toString() {
        return "Transaksi{" + "kodeBarang=" + kodeBarang + ", namaBarang=" + namaBarang + ", jumlah=" + jumlah + ", hargaBarang=" + hargaBarang + ", totalHarga=" + totalHarga + ", bayar=" + bayar + ", kembalian=" + kembalian + '}';
    }
}
