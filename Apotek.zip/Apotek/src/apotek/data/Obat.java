package apotek.data;

import java.io.*;

public class Obat implements Serializable{
    
    private String kodeObat;
    private String namaObat;
    private String jenisObat;
    private String hargaBeli;
    private String hargaJual;

    public Obat() {
    }

    public Obat(String kodeObat, String namaObat, String jenisObat, String hargaBeli, String hargaJual) {
        this.kodeObat = kodeObat;
        this.namaObat = namaObat;
        this.jenisObat = jenisObat;
        this.hargaBeli = hargaBeli;
        this.hargaJual = hargaJual;
    }

    public String getKodeObat() {
        return kodeObat;
    }

    public void setKodeObat(String kodeObat) {
        this.kodeObat = kodeObat;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public String getJenisObat() {
        return jenisObat;
    }

    public void setJenisObat(String jenisObat) {
        this.jenisObat = jenisObat;
    }

    public String getHargaBeli() {
        return hargaBeli;
    }

    public void setHargaBeli(String hargaBeli) {
        this.hargaBeli = hargaBeli;
    }

    public String getHargaJual() {
        return hargaJual;
    }

    public void setHargaJual(String hargaJual) {
        this.hargaJual = hargaJual;
    }

    @Override
    public String toString() {
        return "Obat{" + "kodeObat=" + kodeObat + ", namaObat=" + namaObat + ", jenisObat=" + jenisObat + ", hargaBeli=" + hargaBeli + ", hargaJual=" + hargaJual + '}';
    }
}
