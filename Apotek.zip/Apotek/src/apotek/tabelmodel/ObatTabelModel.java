package apotek.tabelmodel;

import java.util.*;
import javax.swing.table.*;
import apotek.data.Obat;

public class ObatTabelModel extends AbstractTableModel {

    private ArrayList<Obat> obat = new ArrayList();

    public ObatTabelModel(ArrayList<Obat> obat) {
        this.obat = obat;
        Obat o = new Obat();
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "KODE OBAT";
            case 1:
                return "NAMA OBAT";
            case 2:
                return "JENIS OBAT";
            case 3:
                return "HARGA JUAL";
            default:
                return "";
        }
    }

    @Override
    public int getRowCount() {
        return obat.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Obat o = obat.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return o.getKodeObat();
            case 1:
                return o.getNamaObat();
            case 2:
                return o.getJenisObat();
            case 3:
                return o.getHargaJual();
            default:
                return "";
        }
    }
}
