package apotek.tabelmodel;

import java.util.*;
import javax.swing.table.*;
import apotek.data.Karyawan;
import apotek.frame.*;

public class KaryawanTabelModel extends AbstractTableModel {

    private ArrayList<Karyawan> karyawan = new ArrayList();

    public KaryawanTabelModel(ArrayList<Karyawan> karyawan) {
        this.karyawan = karyawan;
        DataKaryawan dK = new DataKaryawan();
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "ID";
            case 1:
                return "NAMA";
            default:
                return "";
        }
    }

    @Override
    public int getRowCount() {
        return karyawan.size();
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Karyawan k = karyawan.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return k.getIdKaryawan();
            case 1:
                return k.getNamaKaryawan();
            default:
                return "";
        }
    }
}
