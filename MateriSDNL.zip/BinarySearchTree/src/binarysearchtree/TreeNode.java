package binarysearchtree;

public class TreeNode {
    int elemen;
    TreeNode leftChild;
    TreeNode rightChild;

    public TreeNode(int elemen) {
        this.elemen = elemen;
    }
}
