package binarysearchtree;

public class TreeList {

    private TreeNode root;

    public TreeList() {
    }

    public void add(int x) {
        if (root == null) {
            root = new TreeNode(x);
        } else {
            TreeNode bantu;
            bantu = root;
            while (bantu != null) {
                if (x < bantu.elemen) {
                    if (bantu.leftChild == null) {
                        bantu.leftChild = new TreeNode(x);
                        bantu = null;
                    } else {
                        bantu = bantu.leftChild;
                    }
                } else {
                    if (bantu.rightChild == null) {
                        bantu.rightChild = new TreeNode(x);
                        bantu = null;
                    } else {
                        bantu = bantu.rightChild;
                    }
                }
            }
        }
    }

    private void preOrder(TreeNode root) {
        if (root != null) {
            System.out.print(root.elemen + " ");
            preOrder(root.leftChild);
            preOrder(root.rightChild);
        }
    }

    private void inOrder(TreeNode root) {
        if (root != null) {
            inOrder(root.leftChild);
            System.out.print(root.elemen + " ");
            inOrder(root.rightChild);
        }
    }

    private void postOrder(TreeNode root) {
        if (root != null) {
            postOrder(root.leftChild);
            postOrder(root.rightChild);
            System.out.print(root.elemen + " ");
        }
    }

    public void preOrder() {
        preOrder(root);
    }

    public void inOrder() {
        inOrder(root);
    }

    public void postOrder() {
        postOrder(root);
    }
}
