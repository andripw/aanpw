package binarysearchtree;

public class BinarySearchTree {

    public static void main(String[] args) {
        TreeList tree = new TreeList();
        tree.add(16);
        tree.add(3);
        tree.add(2);
        tree.add(5);
        tree.add(20);
        tree.add(17);
        tree.add(25);
        System.out.println("Pre Order : ");
        tree.preOrder();
        System.out.println("\nIn Order : ");
        tree.inOrder();
        System.out.println("\nPost Order : ");
        tree.postOrder();
        System.out.println("");
    }    
}
