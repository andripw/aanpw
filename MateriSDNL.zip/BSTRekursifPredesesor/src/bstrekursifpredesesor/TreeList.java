package bstrekursifpredesesor;

public class TreeList {

    private TreeNode root;
    private TreeNode parent;
    private TreeNode predesesor;
    private TreeNode parentPredesesor;

    public TreeList() {
    }

    private void preOrder(TreeNode root) {
        if (root != null) {
            System.out.print(root.elemen + " ");
            preOrder(root.leftChild);
            preOrder(root.rightChild);
        }
    }

    private void inOrder(TreeNode root) {
        if (root != null) {
            inOrder(root.leftChild);
            System.out.print(root.elemen + " ");
            inOrder(root.rightChild);
        }
    }

    private void postOrder(TreeNode root) {
        if (root != null) {
            postOrder(root.leftChild);
            postOrder(root.rightChild);
            System.out.print(root.elemen + " ");
        }
    }

    public void preOrder() {
        preOrder(root);
    }

    public void inOrder() {
        inOrder(root);
    }

    public void postOrder() {
        postOrder(root);
    }

    public TreeNode getNode(int key) {
        TreeNode bantu;
        bantu = root;
        while (bantu != null) {
            if (bantu.elemen == key) {
                return bantu;
            } else {
                if (bantu.elemen > key) {
                    bantu = bantu.leftChild;
                } else {
                    bantu = bantu.rightChild;
                }
            }
        }
        return null;
    }

    public void addRekursif(int x) {
        if (root == null) {
            root = new TreeNode(x);
        } else {
            root.insert(x);
        }
    }

    public TreeNode getParent(int key) {
        TreeNode bantu = root;
        TreeNode parent = null;
        while (bantu != null) {
            if (key == bantu.elemen) {
                return parent;
            } else if (key < bantu.elemen) {
                parent = bantu;
                bantu = bantu.leftChild;
            } else {
                parent = bantu;
                bantu = bantu.rightChild;
            }
        }
        return null;
    }

    public TreeNode hapus012(int key) {
        TreeNode bantu = getNode(key);
        if (bantu == null) {
            return null;
        } else {
            if (bantu.elemen == root.elemen) {
                if (bantu.isLeaf()) {
                    root = null;
                } else if (bantu.rightChild == null) {
                    root = bantu.leftChild;
                } else if (bantu.leftChild == null) {
                    root = bantu.rightChild;
                } else {
                    predesesor = getPredesesor(key);
                    parentPredesesor = getParent(predesesor.elemen);
                    bantu.elemen = getPredesesor(key).elemen;
                    if (parentPredesesor != bantu) {
                        if (predesesor.leftChild != null) {
                            parentPredesesor.rightChild = predesesor.leftChild;
                        } else {
                            parentPredesesor.rightChild = null;
                        }
                    } else {
                        bantu.leftChild = predesesor.leftChild;
                    }
                }
            } else {
                parent = getParent(key);
                if (key < parent.elemen) {
                    if (bantu.isLeaf()) {
                        parent.leftChild = null;
                    } else if (bantu.rightChild == null) {
                        parent.leftChild = bantu.leftChild;
                    } else if (bantu.leftChild == null) {
                        parent.leftChild = bantu.rightChild;
                    } else {
                        predesesor = getPredesesor(key);
                        parentPredesesor = getParent(predesesor.elemen);
                        bantu.elemen = getPredesesor(key).elemen;
                        if (parentPredesesor != bantu) {
                            if (predesesor.leftChild != null) {
                                parentPredesesor.rightChild = predesesor.leftChild;
                            } else {
                                parentPredesesor.rightChild = null;
                            }
                        } else {
                            bantu.leftChild = predesesor.leftChild;
                        }
                    }
                } else {
                    if (bantu.isLeaf()) {
                        parent.rightChild = null;
                    } else if (bantu.rightChild == null) {
                        parent.rightChild = bantu.leftChild;
                    } else if (bantu.leftChild == null) {
                        parent.rightChild = bantu.rightChild;
                    } else {
                        predesesor = getPredesesor(key);
                        parentPredesesor = getParent(predesesor.elemen);
                        bantu.elemen = getPredesesor(key).elemen;
                        if (parentPredesesor != bantu) {
                            if (predesesor.leftChild != null) {
                                parentPredesesor.rightChild = predesesor.leftChild;
                            } else {
                                parentPredesesor.rightChild = null;
                            }
                        } else {
                            bantu.leftChild = predesesor.leftChild;
                        }
                    }
                }
            }
        }
        return bantu;
    }

    public TreeNode getPredesesor(int x) {
        TreeNode bantu = getNode(x);
        if (bantu.leftChild == null) {
            return null;
        } else {
            bantu = bantu.leftChild;
            while (bantu.rightChild != null) {
                bantu = bantu.rightChild;
            }
        }
        return bantu;
    }
}
