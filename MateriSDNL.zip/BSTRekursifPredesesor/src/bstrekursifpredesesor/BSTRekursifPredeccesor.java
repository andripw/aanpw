package bstrekursifpredesesor;

public class BSTRekursifPredeccesor {

    public static void main(String[] args) {
        TreeList tree = new TreeList();
        tree.addRekursif(8);
        tree.addRekursif(6);
        tree.addRekursif(7);
        tree.addRekursif(3);
        tree.addRekursif(5);
        tree.addRekursif(1);
        tree.addRekursif(4);
        tree.addRekursif(15);
        tree.addRekursif(20);
        tree.addRekursif(10);
        tree.addRekursif(18);
        tree.addRekursif(19);
        tree.addRekursif(21);
        System.out.println("Pre Order : ");
        tree.preOrder();

        TreeNode hapus = tree.hapus012(6);
        if (hapus != null) {
            System.out.println("\nPre Order setelah dihapus : ");
            tree.preOrder();
        } else {
            System.out.println("\nData yang dihapus tidak ditemukan");
            tree.preOrder();
        }
        System.out.println("");
    }
}
