package minimumspanningtree;

import java.util.ArrayList;

public class MinimumSpanningTree {

    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.addVertex('A');
        graph.addVertex('B');
        graph.addVertex('C');
        graph.addVertex('D');
        graph.addVertex('E');
        graph.addVertex('F');
        
        graph.addEdge('A', 'B', 2);
        graph.addEdge('A', 'D', 1);
        graph.addEdge('B', 'C', 3);
        graph.addEdge('C', 'D', 5);
        graph.addEdge('C', 'E', 7);
        graph.addEdge('D', 'E', 6);
        graph.addEdge('E', 'F', 4);
        
        int total = 0;
        ArrayList<Edge> edges = graph.prim();
        System.out.println("Algoritma Prim");
        for (Edge edge : edges) {
            System.out.println(edge);
            total += edge.getWeight();
        }
        System.out.println("Total weight is : " + total);
    }  
}
