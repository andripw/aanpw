package minimumspanningtree;

import java.util.*;

public class Graph {

    private int maxVertex = 10;
    private Vertex[] vertexList;
    private int[][] adjancencyMatrix;
    private int countVertex;

    public Graph() {
        maxVertex = 10;
        vertexList = new Vertex[maxVertex];
        adjancencyMatrix = new int[10][10];
        for (int i = 0; i < maxVertex; i++) {
            for (int j = 0; j < maxVertex; j++) {
                if (i == j) {
                    adjancencyMatrix[i][j] = 0;
                } else {
                    adjancencyMatrix[i][j] = -1;
                }
            }
        }
        countVertex = 0;
    }

    public void addVertex(char node) {
        vertexList[countVertex++] = new Vertex(node);
    }

    public void addEdge(int a, int b, int c) {
        adjancencyMatrix[a][b] = c;
        adjancencyMatrix[b][a] = c;
    }

    public void addEdge(char a, char b, int c) {
        adjancencyMatrix[indexVertex(a)][indexVertex(b)] = c;
        adjancencyMatrix[indexVertex(b)][indexVertex(a)] = c;
    }

    private int indexVertex(char index) {
        for (int i = 0; i < countVertex; i++) {
            if (vertexList[i].label == index) {
                return i;
            }
        }
        return -1;
    }

    public ArrayList<Edge> prim() {
        int seed = 0;
        ArrayList<Edge> primEdges = new ArrayList();
        ArrayList<Integer> primVertex = new ArrayList();
        primVertex.add(seed);
        vertexList[0].flagVisited = true;
        while (primVertex.size() < countVertex) {
            int tempMinWeight = Integer.MAX_VALUE;
            int tempMinIndexVertexI = -1;
            int tempMinIndexVertexJ = -1;
            for (int i = 0; i < primVertex.size(); i++) {
                for (int j = 0; j < countVertex; j++) {
                    if (adjancencyMatrix[primVertex.get(i)][j] > 0 && vertexList[j].flagVisited == false
                            && adjancencyMatrix[primVertex.get(i)][j] < tempMinWeight) {
                        tempMinWeight = adjancencyMatrix[primVertex.get(i)][j];
                        tempMinIndexVertexI = primVertex.get(i);
                        tempMinIndexVertexJ = j;
                    }
                }
            }
            if (tempMinWeight > 0) {
                primVertex.add(tempMinIndexVertexJ);
                vertexList[tempMinIndexVertexJ].flagVisited = true;
                primEdges.add(new Edge(tempMinIndexVertexI, tempMinIndexVertexJ, tempMinWeight));
            }
        }
        return primEdges;
    }
}
