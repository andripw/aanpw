package testgraph;

public class TestDFS {

    public static void main(String[] args) {
        Graph graph = new Graph();
        graph.addVertex('A');//1
        graph.addVertex('B');//2
        graph.addVertex('C');//3
        graph.addVertex('D');//4
        graph.addVertex('E');//5
        graph.addVertex('F');//6

        graph.addEdge('A', 'B', 1);
        graph.addEdge('A', 'C', 1);
        graph.addEdge('A', 'D', 1);
        graph.addEdge('B', 'C', 1);
        graph.addEdge('B', 'E', 1);
        graph.addEdge('C', 'D', 1);
        graph.addEdge('C', 'E', 1);
        graph.addEdge('C', 'F', 1);
        graph.addEdge('D', 'F', 1);

        System.out.println("Adjacency Matrix : ");
        graph.show();
        System.out.print("DFS : ");
        System.out.print("");
        graph.dfs();
    }
}
