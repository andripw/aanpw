package testgraph;

import java.util.LinkedList;

public class Queue<E> {

    private LinkedList<E> linkedList;

    public Queue() {
        linkedList = new LinkedList();
    }

    public void add(E e) {
        linkedList.addLast(e);
    }

    public E remove() {
        return linkedList.removeFirst();
    }

    public boolean isEmpty() {
        return linkedList.isEmpty();
    }
}
