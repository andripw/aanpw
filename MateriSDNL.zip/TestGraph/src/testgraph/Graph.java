package testgraph;

import java.util.*;

public class Graph {

    private int maxVertex = 10;
    private Vertex[] vertexList;
    private int[][] adjancencyMatrix;
    private int countVertex;

    public Graph() {
        maxVertex = 10;
        vertexList = new Vertex[maxVertex];
        adjancencyMatrix = new int[10][10];
        for (int i = 0; i < maxVertex; i++) {
            for (int j = 0; j < maxVertex; j++) {
                if (i == j) {
                    adjancencyMatrix[i][j] = 0;
                } else {
                    adjancencyMatrix[i][j] = -1;
                }
            }
        }
        countVertex = 0;
    }

    public void addVertex(char node) {
        vertexList[countVertex++] = new Vertex(node);
    }

    public void addEdge(int a, int b, int c) {
        adjancencyMatrix[a][b] = c;
        adjancencyMatrix[b][a] = c;
    }

    public void addEdge(char a, char b, int c) {
        adjancencyMatrix[indexVertex(a)][indexVertex(b)] = c;
        adjancencyMatrix[indexVertex(b)][indexVertex(a)] = c;
    }

    private int indexVertex(char index) {
        for (int i = 0; i < countVertex; i++) {
            if (vertexList[i].label == index) {
                return i;
            }
        }
        return -1;
    }

    //index vertex = rreturn index array of vertex
    public void show() {
        for (int i = 0; i < countVertex; i++) {
            for (int j = 0; j < countVertex; j++) {
                System.out.printf(adjancencyMatrix[i][j] + " ");
            }
            System.out.println();
        }
    }//show = print matix m x n

    public void dfs() {
        int seed = 0;
        Stack tumpukan = new Stack();
        tumpukan.push(vertexList[seed]);
        while (!tumpukan.isEmpty()) {
            Vertex cetak = (Vertex) tumpukan.pop();
            if (cetak.flagVisited == false) {
                System.out.printf(cetak.label + " ");
                cetak.flagVisited = true;
                for (int i = countVertex - 1; i >= 0; i--) {
                    if (adjancencyMatrix[indexVertex(cetak.label)][i] > 0
                            && vertexList[i].flagVisited == false) {
                        tumpukan.push(vertexList[i]);
                    }
                }
            }
        }
    }

    public void bfs() {
        Queue queue = new Queue();
        int seed = 0;
        queue.add(vertexList[seed]);
        while (!queue.isEmpty()) {
            Vertex vertex = (Vertex) queue.remove();
            if (!vertex.flagVisited) {
                System.out.print(vertex.label + " ");
                vertex.flagVisited = true;
                for (int i = 1; i < vertexList.length; i++) {
                    if (adjancencyMatrix[indexVertex(vertex.label)][i] > 0) {
                        if(!vertexList[i].flagVisited){
                            queue.add(vertexList[i]);
                        }
                    }
                }
            }
        }
        System.out.println("");
    }
}
