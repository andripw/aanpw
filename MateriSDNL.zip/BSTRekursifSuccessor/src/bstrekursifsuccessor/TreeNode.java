package bstrekursifsuccessor;

public class TreeNode {

    int elemen;
    TreeNode leftChild;
    TreeNode rightChild;

    public TreeNode(int x) {
        this.elemen = x;
    }

    public void insert(int x) {
        if (elemen > x) {
            if (leftChild == null) {
                leftChild = new TreeNode(x);
            } else {
                leftChild.insert(x);
            }
        } else {
            if (rightChild == null) {
                rightChild = new TreeNode(x);
            } else {
                rightChild.insert(x);
            }
        }
    }
    
    public boolean isLeaf(){
        if(leftChild == null && rightChild == null){
            return true;
        } 
        return false;
    }
    
}
