package bstrekursifsuccessor;

public class TreeList {

    private TreeNode root;
    private TreeNode parent;
    private TreeNode successor;
    private TreeNode parentSuccessor;

    public TreeList() {
    }

    private void preOrder(TreeNode root) {
        if (root != null) {
            System.out.print(root.elemen + " ");
            preOrder(root.leftChild);
            preOrder(root.rightChild);
        }
    }

    private void inOrder(TreeNode root) {
        if (root != null) {
            inOrder(root.leftChild);
            System.out.print(root.elemen + " ");
            inOrder(root.rightChild);
        }
    }

    private void postOrder(TreeNode root) {
        if (root != null) {
            postOrder(root.leftChild);
            postOrder(root.rightChild);
            System.out.print(root.elemen + " ");
        }
    }

    public void preOrder() {
        preOrder(root);
    }

    public void inOrder() {
        inOrder(root);
    }

    public void postOrder() {
        postOrder(root);
    }

    public TreeNode getNode(int key) {
        TreeNode bantu;
        bantu = root;
        while (bantu != null) {
            if (bantu.elemen == key) {
                return bantu;
            } else {
                if (bantu.elemen > key) {
                    bantu = bantu.leftChild;
                } else {
                    bantu = bantu.rightChild;
                }
            }
        }
        return null;
    }

    public void addRekursif(int x) {
        if (root == null) {
            root = new TreeNode(x);
        } else {
            root.insert(x);
        }
    }

    public TreeNode getParent(int key) {
        TreeNode bantu = root;
        TreeNode parent = null;
        while (bantu != null) {
            if (key == bantu.elemen) {
                return parent;
            } else if (key < bantu.elemen) {
                parent = bantu;
                bantu = bantu.leftChild;
            } else {
                parent = bantu;
                bantu = bantu.rightChild;
            }
        }
        return null;
    }

    public TreeNode hapus012(int key) {
        TreeNode bantu = getNode(key);
        if (bantu == null) {
            return null;
        } else {
            if (bantu.elemen == root.elemen) {
                if (bantu.isLeaf()) {
                    root = null;
                } else if (bantu.rightChild == null) {
                    root = bantu.leftChild;
                } else if (bantu.leftChild == null) {
                    root = bantu.rightChild;
                } else {
                    successor = getSuccessor(key);
                    parentSuccessor = getParent(successor.elemen);
                    bantu.elemen = getSuccessor(key).elemen;
                    if (parentSuccessor != bantu) {
                        if (successor.rightChild != null) {
                            parentSuccessor.leftChild = successor.rightChild;
                        } else {
                            parentSuccessor.leftChild = null;
                        }
                    } else {
                        bantu.rightChild = successor.rightChild;
                    }
                }
            } else {
                parent = getParent(key);
                if (key < parent.elemen) {
                    if (bantu.isLeaf()) {
                        parent.leftChild = null;
                    } else if (bantu.rightChild == null) {
                        parent.leftChild = bantu.leftChild;
                    } else if (bantu.leftChild == null) {
                        parent.leftChild = bantu.rightChild;
                    } else {
                        successor = getSuccessor(key);
                        parentSuccessor = getParent(successor.elemen);
                        bantu.elemen = getSuccessor(key).elemen;
                        if (parentSuccessor != bantu) {
                            if (successor.rightChild != null) {
                                parentSuccessor.leftChild = successor.rightChild;
                            } else {
                                parentSuccessor.leftChild = null;
                            }
                        } else {
                            bantu.rightChild = successor.rightChild;
                        }
                    }
                } else {
                    if (bantu.isLeaf()) {
                        parent.rightChild = null;
                    } else if (bantu.rightChild == null) {
                        parent.rightChild = bantu.leftChild;
                    } else if (bantu.leftChild == null) {
                        parent.rightChild = bantu.rightChild;
                    } else {
                        successor = getSuccessor(key);
                        parentSuccessor = getParent(successor.elemen);
                        bantu.elemen = getSuccessor(key).elemen;
                        if (parentSuccessor != bantu) {
                            if (successor.rightChild != null) {
                                parentSuccessor.leftChild = successor.rightChild;
                            } else {
                                parentSuccessor.leftChild = null;
                            }
                        } else {
                            bantu.rightChild = successor.rightChild;
                        }
                    }
                }
                return bantu;
            }
        }
        return null;
    }

    public TreeNode getSuccessor(int x) {
        TreeNode bantu = getNode(x);
        if (bantu.rightChild == null) {
            return null;
        } else {
            bantu = bantu.rightChild;
            while (bantu.leftChild != null) {
                bantu = bantu.leftChild;
            }
        }
        return bantu;
    }
}
