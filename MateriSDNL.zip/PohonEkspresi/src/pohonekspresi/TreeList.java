package pohonekspresi;

import java.util.*;

public class TreeList {

    private TreeNode root;

    public TreeList() {
    }

    private void preOrder(TreeNode root) {
        if (root != null) {
            System.out.print(root.elemen + " ");
            preOrder(root.leftChild);
            preOrder(root.rightChild);
        }
    }

    private void inOrder(TreeNode root) {
        if (root != null) {
            if (!isOperator(root)) {
                System.out.print(root.elemen);
            } else {
                System.out.print("(");
                inOrder(root.leftChild);
                System.out.print(root.elemen + " ");
                inOrder(root.rightChild);
                System.out.print(")");
            }
        }
    }

    private void postOrder(TreeNode root) {
        if (root != null) {
            postOrder(root.leftChild);
            postOrder(root.rightChild);
            System.out.print(root.elemen + " ");
        }
    }

    public void preOrder() {
        preOrder(root);
    }

    public void inOrder() {
        inOrder(root);
    }

    public void postOrder() {
        postOrder(root);
    }

    public void addExpressionInfix(String s) {
        Stack<TreeNode> operand = new Stack();
        Stack<TreeNode> operator = new Stack();
        TreeNode akar, kanan, kiri;

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '+' || c == '-' || c == '*' || c == '/' || c == '^') {
                operator.push(new TreeNode(c));
            } else if (c == ')') {
                akar = operator.pop();
                while (akar.elemen != '(') {
                    kanan = operand.pop();
                    kiri = operand.pop();
                    akar.rightChild = kanan;
                    akar.leftChild = kiri;
                    operand.push(combine(akar, kiri, kanan));
                    akar = operator.pop();
                }
            } else {
                operand.push(new TreeNode(c));
            }
        }
        root = operand.pop();
    }

    private TreeNode combine(TreeNode operator, TreeNode nodeLeft, TreeNode nodeRight) {
        operator.leftChild = nodeLeft;
        operator.rightChild = nodeRight;
        return operator;
    }

    public boolean isOperator(TreeNode root) {
        if (root.elemen == '+' || root.elemen == '-' || root.elemen == '*' || root.elemen == '/') {
            return true;
        }
        return false;
    }
}
