package pohonekspresi;

public class PohonEkspresi {

    public static void main(String[] args) {
        String s = "(A+(B-C))";
        TreeList tree = new TreeList();
        System.out.print("Infix : ");
        tree.addExpressionInfix(s);
        tree.inOrder();
        System.out.println("");
    }
}
