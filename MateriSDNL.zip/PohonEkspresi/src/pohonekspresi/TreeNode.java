package pohonekspresi;

public class TreeNode {

    char elemen;
    TreeNode leftChild;
    TreeNode rightChild;

    public TreeNode(char x) {
        this.elemen = x;
    }
}
