package bstrekursif;

public class BSTRekursif {

    public static void main(String[] args) {
        TreeList tree = new TreeList();
        tree.addRekursif(23);
        tree.addRekursif(19);
        tree.addRekursif(5);
        tree.addRekursif(45);
        tree.addRekursif(35);
        tree.addRekursif(42);
        System.out.println("Pre Order : ");
        tree.preOrder();
        System.out.println("\nIn Order : ");
        tree.inOrder();
        System.out.println("\nPost Order : ");
        tree.postOrder();
        System.out.println("");
             
        TreeNode hapus = tree.hapus01(35);
        if(hapus != null) {
            System.out.println("\nPre Order setelah dihapus :");
            tree.preOrder();
        } else {
            System.out.println("\nData yang dihapus tidak ditemukan");
            tree.preOrder();
        }
        System.out.println("");
    }
}
