package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;
import org.me.sewacamping.SewaCampingWS_Service;
import tool.DataBaseConnection;

public class UpdateBrg extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_9090/SewaCampingWS/SewaCampingWS.wsdl")
    private SewaCampingWS_Service service;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet UpdateBrg</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet UpdateBrg at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int idBarang = Integer.parseInt(request.getParameter("idBarang"));
        String namaBarang = request.getParameter("namaBarang");
        String jumlah = request.getParameter("jumlah");
        String harga = request.getParameter("harga");

        DataBaseConnection koneksi = new DataBaseConnection();
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "update barang set nama_barang ='" + namaBarang + "', jumlah_barang ='"
                    + jumlah + "', harga_barang='" + harga + "' where id_barang =" + idBarang + "";
            Statement statement = koneksi.getConnection().createStatement();
            int update = statement.executeUpdate(query);
            response.sendRedirect("UpdateBarang.jsp");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String updateBarang(int idBarang, java.lang.String namaBarang, 
            java.lang.String jumlah, java.lang.String harga) {
        org.me.sewacamping.SewaCampingWS port = service.getSewaCampingWSPort();
        return port.updateBarang(idBarang, namaBarang, jumlah, harga);
    }
}
