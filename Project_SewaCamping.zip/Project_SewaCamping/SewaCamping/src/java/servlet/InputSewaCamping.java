package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.WebServiceRef;
import org.me.sewacamping.SewaCampingWS_Service;
import tool.DataBaseConnection;

public class InputSewaCamping extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_9090/SewaCampingWS/SewaCampingWS.wsdl")
    private SewaCampingWS_Service service;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet InputSewaCamping</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet InputSewaCamping at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DataBaseConnection koneksi = new DataBaseConnection();
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        try {
            int stockLama = 0;
            String query = "select * from barang  where id_barang = " + request.getParameter("idBrg");
            Statement statement = koneksi.getConnection().createStatement();
            ResultSet result = statement.executeQuery(query);
            while (result.next()) {
                stockLama = Integer.parseInt(result.getString(3));
            }

            int stockBaru = stockLama - Integer.parseInt(request.getParameter("jumlahBrg"));

            statement.close();

            String query2 = "update barang set jumlah_barang = '" + stockBaru + "' where id_barang = '"
                    + request.getParameter("idBrg") + "'";
            Statement st2 = koneksi.getConnection().createStatement();
            st2.executeUpdate(query2);
            st2.close();

            String query3 = "insert into sewa (ID_BARANG, ID_PELANGGAN, JUMLAH_BARANG, HARGA_BARANG, "
                    + "TANGGAL_SEWA, TANGGAL_KEMBALI)"
                    + "values('" + request.getParameter("idBrg") + "','"
                    + session.getAttribute("userid") + "','"
                    + request.getParameter("jumlahBrg") + "','"
                    + request.getParameter("hargaBrg") + "','"
                    + request.getParameter("tglSewa") + "','"
                    + request.getParameter("tglKembali") + "')";
            Statement statement3 = koneksi.getConnection().createStatement();
            statement3.executeQuery(query3);
            statement3.close();
            response.sendRedirect("HalamanDetailBarangRansel.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String inputSewa(java.lang.String idPelanggan, java.lang.String idBarang, 
            java.lang.String jumlahBarang, java.lang.String hargaBarang, 
            java.lang.String tglSewa, java.lang.String tglKembali) {
        org.me.sewacamping.SewaCampingWS port = service.getSewaCampingWSPort();
        return port.inputSewa(idPelanggan, idBarang, jumlahBarang, hargaBarang, tglSewa, tglKembali);
    }
}
