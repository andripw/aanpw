package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;
import org.me.sewacamping.SewaCampingWS_Service;

public class TambahBarang extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_9090/SewaCampingWS/SewaCampingWS.wsdl")
    private SewaCampingWS_Service service;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet TambahBarang</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet TambahBarang at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        String namaBarang = request.getParameter("namaBarang");
        String jumlah = request.getParameter("jumlah");
        String harga = request.getParameter("harga");
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/camping";
            String username = "root";
            String password = "Root123";
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement ps;

            ps = conn.prepareStatement("insert into barang (NAMA_BARANG, JUMLAH_BARANG, HARGA_BARANG) values('"
                    + namaBarang + "','" + jumlah + "','" + harga + "')",
                    PreparedStatement.RETURN_GENERATED_KEYS);
            ps.executeUpdate();
            response.sendRedirect("InputBarang.jsp");
            conn.commit();
        } catch (Exception e) {
            System.out.print(e);
            e.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String tambahBarang(java.lang.String namaBarang, java.lang.String jumlah, java.lang.String harga) {
        org.me.sewacamping.SewaCampingWS port = service.getSewaCampingWSPort();
        return port.tambahBarang(namaBarang, jumlah, harga);
    }
}
