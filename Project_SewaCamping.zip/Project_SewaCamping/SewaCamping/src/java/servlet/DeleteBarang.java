package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;
import org.me.sewacamping.SewaCampingWS_Service;
import tool.DataBaseConnection;

public class DeleteBarang extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_9090/SewaCampingWS/SewaCampingWS.wsdl")
    private SewaCampingWS_Service service;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DeleteBarang</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DeleteBarang at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DataBaseConnection conn = new DataBaseConnection();
        PrintWriter out = response.getWriter();

        String idBarang = request.getParameter("idBarang");

        try {

            String query = "delete from barang where ID_BARANG= '" + idBarang + "'";
            java.sql.Statement statement = conn.getConnection().createStatement();
            int delete = statement.executeUpdate(query);
            response.sendRedirect("DeleteBarang.jsp");
        } catch (Exception ex) {
            out.println("message: " + ex.getMessage());
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String deleteBarang(java.lang.String idBarang) {
        org.me.sewacamping.SewaCampingWS port = service.getSewaCampingWSPort();
        return port.deleteBarang(idBarang);
    }
}
