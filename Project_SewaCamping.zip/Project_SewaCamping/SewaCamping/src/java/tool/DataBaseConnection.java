package tool;

import java.sql.*;

public class DataBaseConnection {

    private String jdbcURL = "jdbc:mysql://localhost:3306/camping";
    private String user = "root";
    private String password = "Root123";
    private Connection connection;

    public DataBaseConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, user, password);
            System.out.println("Koneksi berhasil");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isConnected() {
        if (connection != null) {
            System.out.println("berhasil");
            return true;
        } else {
            return false;
        }
    }

    public boolean getClosed() {
        if (isConnected()) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            return true;
        } else {
            return false;
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public static void main(String[] args) {
        DataBaseConnection koneksi = new DataBaseConnection();
    }
}
