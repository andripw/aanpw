package org.me.sewacamping;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import java.sql.*;
import tools.DataBaseConnection;

@WebService(serviceName = "SewaCampingWS")
@Stateless()
public class SewaCampingWS {

    @WebMethod(operationName = "tambahBarang")
    public String tambahBarang(@WebParam(name = "namaBarang") 
            String namaBarang, @WebParam(name = "jumlah") 
                    String jumlah, @WebParam(name = "harga") String harga) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/camping";
            String username = "root";
            String password = "Root123";
            Connection conn = DriverManager.getConnection(url, username, password);
            PreparedStatement ps;

            ps = conn.prepareStatement("insert into barang (NAMA_BARANG, JUMLAH_BARANG, HARGA_BARANG) values('"
                    + namaBarang + "','" + jumlah + "','" + harga + "')",
                    PreparedStatement.RETURN_GENERATED_KEYS);
            ps.executeUpdate();
            conn.commit();
        } catch (Exception e) {
            System.out.print(e);
            e.printStackTrace();
        }
        return "";
    }

    @WebMethod(operationName = "updateBarang")
    public String updateBarang(@WebParam(name = "idBarang") int idBarang, @WebParam(name = "namaBarang") 
            String namaBarang, @WebParam(name = "jumlah") String jumlah, @WebParam(name = "harga") String harga) {
        DataBaseConnection koneksi = new DataBaseConnection();
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            String query = "update barang set nama_barang ='" + namaBarang + "', jumlah_barang ='" 
                    + jumlah + "', harga_barang='" + harga + "' where id_barang =" + idBarang + "";
            Statement statement = koneksi.getConnection().createStatement();
            int update = statement.executeUpdate(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    @WebMethod(operationName = "deleteBarang")
    public String deleteBarang(@WebParam(name = "idBarang") String idBarang) {
        DataBaseConnection conn = new DataBaseConnection();     
        try {

            String query = "delete from barang where ID_BARANG= '" + idBarang + "'";
            java.sql.Statement statement = conn.getConnection().createStatement();
            int delete = statement.executeUpdate(query);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    @WebMethod(operationName = "deletePelanggan")
    public String deletePelanggan(@WebParam(name = "idPelanggan") String idPelanggan) {
        DataBaseConnection conn = new DataBaseConnection();      
        try {

            String query = "delete from pelanggan where ID_PELANGGAN=" + idPelanggan + "";
            java.sql.Statement statement = conn.getConnection().createStatement();
            int delete = statement.executeUpdate(query);
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    @WebMethod(operationName = "inputSewa")
    public String inputSewa(@WebParam(name = "idPelanggan") String idPelanggan, @WebParam(name = "idBarang") 
            String idBarang, @WebParam(name = "jumlahBarang") String jumlahBarang, @WebParam(name = "hargaBarang") 
                    String hargaBarang, @WebParam(name = "tglSewa") String tglSewa, @WebParam(name = "tglKembali") 
                            String tglKembali) {
        DataBaseConnection koneksi = new DataBaseConnection();
        try {
            int stockLama = 0;
            String query = "select * from barang  where id_barang = " + idBarang;
            Statement statement = koneksi.getConnection().createStatement();
            ResultSet result = statement.executeQuery(query);
            while (result.next()) {
                stockLama = Integer.parseInt(result.getString(3));
            }

            int stockBaru = stockLama - Integer.parseInt(jumlahBarang);

            statement.close();

            String query2 = "update barang set jumlah_barang = '" + stockBaru + "' where id_barang = '" 
                    + idBarang + "'";
            Statement st2 = koneksi.getConnection().createStatement();
            st2.executeUpdate(query2);
            st2.close();
            
            String query3 = "insert into sewa (ID_BARANG, ID_PELANGGAN, JUMLAH_BARANG, HARGA_BARANG, "
                    + "TANGGAL_SEWA, TANGGAL_KEMBALI)"
                    + "values('"+ idBarang + "','"
                    + idPelanggan + "','" 
                    + jumlahBarang + "','"
                    + hargaBarang + "','"
                    + tglSewa + "','"
                    + tglKembali + "')";
            Statement statement3 = koneksi.getConnection().createStatement();
            statement3.executeQuery(query3);
            statement3.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}
