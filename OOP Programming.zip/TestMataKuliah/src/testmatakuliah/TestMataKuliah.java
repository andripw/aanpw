package testmatakuliah;

import java.util.Scanner;

public class TestMataKuliah {

    public static void main(String[] args) {
        String namaMahasiswa;
        String NIM;
        int jumlahMK;
        String matakuliah;
        MataKuliah[] daftarMataKuliah;    

        Scanner nameMhs;
        nameMhs = new Scanner(System.in);
        System.out.printf("Nama\t: ");
        namaMahasiswa = nameMhs.next();

        Scanner nim;
        nim = new Scanner(System.in);
        System.out.printf("NIM\t: ");
        NIM = nim.next();

        Scanner kbdIn = new Scanner(System.in);
        System.out.printf("Masukan Jumlah Mata Kuliah : ");
        jumlahMK = kbdIn.nextInt();

        daftarMataKuliah = new MataKuliah[jumlahMK];
        for (int i = 0; i < jumlahMK; i++) {
            daftarMataKuliah[i] = new MataKuliah();
            System.out.printf("Mata Kuliah ke " + i + " : ");
            daftarMataKuliah[i].setMatakuliah(kbdIn.next());            
            try {
                System.out.printf("SKS ke   " + i + " : ");
                daftarMataKuliah[i].setSKS(kbdIn.nextInt());
                System.out.printf("UTS 1 ke " + i + " : ");
                daftarMataKuliah[i].setUts1(kbdIn.nextDouble());
                System.out.printf("UTS 2 ke " + i + " : ");
                daftarMataKuliah[i].setUts2(kbdIn.nextDouble());
                System.out.printf("UAS ke   " + i + " : ");
                daftarMataKuliah[i].setUas(kbdIn.nextDouble());
            } catch (Exception ex) {
                System.out.println(ex);
            }
            daftarMataKuliah[i].inputTugas();
        }
        System.out.printf("|====================================================================================|\n");
        System.out.printf("|No\tNama\tSKS\tTugas\tUTS 1\tUTS 2\tUAS\tNilai Angka\tNilai Huruf  |\n");
        System.out.printf("|====================================================================================|\n");
        for (int i = 0; i < jumlahMK; i++) {
            System.out.printf("|%-3d", (i+1), " ");
            daftarMataKuliah[i].printInfo();
        }
        System.out.printf("|====================================================================================|\n");
    }
}
