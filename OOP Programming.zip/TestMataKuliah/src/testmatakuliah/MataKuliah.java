package testmatakuliah;

import java.util.Scanner;

public class MataKuliah {

    private String matakuliah;
    private int SKS;
    private double uts1;
    private double uts2;
    private double uas;
    private final int jumlahTugas = 5;
    private double[] tugas;

    public MataKuliah(String matakuliah, int SKS, double uts1, double uts2, double uas, double[] tugas) {
        this.matakuliah = matakuliah;
        this.SKS = SKS;
        this.uts1 = uts1;
        this.uts2 = uts2;
        this.uas = uas;
        this.tugas = tugas;
        tugas = new double[jumlahTugas];
    }

    public MataKuliah() {
        tugas = new double[jumlahTugas];
    }

    public String getMatakuliah() {
        return matakuliah;
    }

    public void setMatakuliah(String matakuliah) {
        this.matakuliah = matakuliah;
    }

    public int getSKS() {
        return SKS;
    }

    public void setSKS(int SKS) throws Exception {
        if (SKS >= 0 && SKS <= 24) {
            this.SKS = SKS;
        } else {
            throw new Exception("Error SKS");
        }
    }

    public double[] getTugas() {
        return tugas;
    }

    public void setTugas(double[] tugas) throws Exception {
        this.tugas = tugas;
    }

    public double getUts1() {
        return uts1;
    }

    public void setUts1(double uts1) throws Exception {
        if (uts1 >= 0 && uts1 <= 100) {
            this.uts1 = uts1;
        } else {
            throw new Exception("Error UTS 1");
        }
    }

    public double getUts2() {
        return uts2;
    }

    public void setUts2(double uts2) throws Exception {
        if (uts2 >= 0 && uts2 <= 100) {
            this.uts2 = uts2;
        } else {
            throw new Exception("Error UTS 2");
        }
    }

    public double getUas() {
        return uas;
    }

    public void setUas(double uas) throws Exception {
        if (uas >= 0 && uas <= 100) {
            this.uas = uas;
        } else {
            throw new Exception("Error UAS");
        }
    }

    public void inputTugas() {
        Scanner kbdIn;
        kbdIn = new Scanner(System.in);
        for (int i = 0; i < jumlahTugas; i++) {
            System.out.print("Nilai Tugas ke " + i + " : ");
            tugas[i] = kbdIn.nextDouble();
        }
    }

    public double calcAverageTugas() {
        double sigma = 0;
        for (int i = 0; i < jumlahTugas; i++) {
            sigma = sigma + tugas[i];
        }
        return (sigma / jumlahTugas);
    }

    public double calcNilaiAngka() {
        return ((0.3 * uts1) + (0.3 * uts2) + (0.3 * uas) + (0.1 * calcAverageTugas()));
    }

    public char calcNilaiHuruf() {
        double nilai = calcNilaiAngka();
        if (nilai >= 90 && nilai <= 100) {
            return ('A');
        } else if (nilai >= 80) {
            return ('B');
        } else if (nilai >= 65) {
            return ('C');
        } else if (nilai >= 50) {
            return ('D');
        } else {
            return ('E');
        }
    }

    public void printInfo() {
        System.out.printf("%8s", this.getMatakuliah());
        System.out.printf("\t%s", this.getSKS());
        System.out.printf("\t%.2f\t", this.calcAverageTugas());
        System.out.printf("%.2f\t", this.getUts1());
        System.out.printf("%.2f\t", this.getUts2());
        System.out.printf("%.2f\t", this.getUas());
        System.out.printf("%.2f\t", this.calcNilaiAngka());
        System.out.printf("\t%c\t     |\n", this.calcNilaiHuruf());
    }
}
