package testthreadrandom;

public class TestThreadRunner {

    public static void main(String[] args) {
        Runner a = new Runner("A");
        Runner b = new Runner("B");
        Runner c = new Runner("C");
        a.start();
        b.start();
        c.start();
        try {
            a.join();
            b.join();
            c.join();
        } catch (InterruptedException e) {
        }
    }
}
