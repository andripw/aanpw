package testthreadrandom;

import java.util.Random;

public class Runner extends Thread {

    private String name = null;
    public static Boolean finished = false;
    public static Random rand = new Random();
    private int distance = 0;
    private final int target = 100;

    public Runner(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println("Thread " + this.name + " is running");
        try {
            while (finished == false) {
                if (this.distance < this.target) {
                    this.distance += rand.nextInt(10);
                } else {
                    break;
                }
                Thread.sleep(1000);
                System.out.println("Thread " + this.name + " distance : " + this.distance);
            }
            finished = true;
            System.out.println("Thread " + this.name + " is finished with distance " + this.distance);
        } catch (InterruptedException e) {
        }
    }

    @Override
    public synchronized void start() {
        super.start();
        System.out.println("Thread " + this.name + " is started");
    }
}
