package testthreethread;

public class ThreeThread extends Thread {

    public ThreeThread(String nama) {
        super(nama);
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(i + " Thread " + getName());
            try {
                Thread.sleep((int) (Math.random() * 1000));
            } catch (InterruptedException e) {

            }
        }
        System.out.println("Exit " + getName());
    }

}
