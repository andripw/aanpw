package testthreethread;

public class TestThreeThread {

    public static void main(String[] args) {
        ThreeThread a = new ThreeThread("A");
        ThreeThread b = new ThreeThread("B");
        ThreeThread c = new ThreeThread("C");
        a.start();
        b.start();
        c.start();
        try{
            a.join();
            b.join();
            c.join();
        }catch(InterruptedException e){
            
        }
    }

}
