package testthread4;

public class TestThread4 {

    public static void main(String[] args) {

        for (int i = 1; i <= 5; ++i){
            System.out.println("main before: iterasi ke" + i);
//            Thread.yield();
        }
        MyThread4 t1, t2, t3;

        t1 = new MyThread4();
        t2 = new MyThread4();
        t3 = new MyThread4();

//        t1.setX(10); 
// Bisa diakses

        for (int i = 1; i <= 5; ++i){
            System.out.println("main after: iterasi ke" + i);
//            Thread.yield();
        }
        System.out.println("MAIN PROGRAM Stopping!!!!!");        
        
    }
}
