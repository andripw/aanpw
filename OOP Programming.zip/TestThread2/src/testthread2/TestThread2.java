package testthread2;

public class TestThread2 {

    public static void main(String[] args) {

        for (int i = 1; i <= 5; ++i){
            System.out.println("main before: iterasi ke" + i);
//            Thread.yield();
        }

        Thread t1, t2, t3;
        
        // Create an anonymous inner class that implements Runnable interface
        t1 = new Thread (new MyThread2()); 
        t2 = new Thread (new MyThread2());
        t3 = new Thread (new MyThread2());

//        t1.setX(10); 
// Tidak bisa di akses t : Thread, Dimana Thread <= MyThread2
// berbeda dengan cara 1 t : MyThread1, dimana MyThread1 extends Thread 

        t1.start();
        t2.start();
        t3.start();

        for (int i = 1; i <= 5; ++i){
            System.out.println("main after: iterasi ke" + i);
//            Thread.yield();
        }
        System.out.println("MAIN PROGRAM Stopping!!!!!");        

    }
}
