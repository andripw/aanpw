package testnilai;
public class Nilai {
    private String dasarKomputer;
    private String pbo1;
    private String dasarKomjarkom;
    private String ppkmb2;
    private String pendidikanPancasila;
    private String pendidikanAgama;
    private String teologiMoral;
    private String kalkulus;
    private String statistika;
    private double uts1;
    private double uts2;
    private double uas;

    public Nilai() {
    }
    public Nilai(String dasarKomputer, String pbo1, String dasarKomjarkom, String ppkmb2, 
                 String pendidikanPancasila, String pendidikanAgama, String teologiMoral, 
                 String kalkulus, String statistika, double uts1, double uts2, double uas) {
        this.dasarKomputer = dasarKomputer;
        this.pbo1 = pbo1;
        this.dasarKomjarkom = dasarKomjarkom;
        this.ppkmb2 = ppkmb2;
        this.pendidikanPancasila = pendidikanPancasila;
        this.pendidikanAgama = pendidikanAgama;
        this.teologiMoral = teologiMoral;
        this.kalkulus = kalkulus;
        this.statistika = statistika;
        this.uts1 = uts1;
        this.uts2 = uts2;
        this.uas = uas;
    }

    public void setDasarKomputer(String dasarKomputer) {
        this.dasarKomputer = dasarKomputer;
    }
    public void setPbo1(String pbo1) {
        this.pbo1 = pbo1;
    }
    public void setDasarKomjarkom(String dasarKomjarkom) {
        this.dasarKomjarkom = dasarKomjarkom;
    }
    public void setPpkmb2(String ppkmb2) {
        this.ppkmb2 = ppkmb2;
    }
    public void setPendidikanPancasila(String pendidikanPancasila) {
        this.pendidikanPancasila = pendidikanPancasila;
    }
    public void setPendidikanAgama(String pendidikanAgama) {
        this.pendidikanAgama = pendidikanAgama;
    }
    public void setTeologiMoral(String teologiMoral) {
        this.teologiMoral = teologiMoral;
    }
    public void setKalkulus(String kalkulus) {
        this.kalkulus = kalkulus;
    }
    public void setStatistika(String statistika) {
        this.statistika = statistika;
    }
    public void setUts1(double uts1) {
        this.uts1 = uts1;
    }
    public void setUts2(double uts2) {
        this.uts2 = uts2;
    }
    public void setUas(double uas) {
        this.uas = uas;
    }

    public String getDasarKomputer() {
        return dasarKomputer;
    }
    public String getPbo1() {
        return pbo1;
    }
    public String getDasarKomjarkom() {
        return dasarKomjarkom;
    }
    public String getPpkmb2() {
        return ppkmb2;
    }
    public String getPendidikanPancasila() {
        return pendidikanPancasila;
    }
    public String getPendidikanAgama() {
        return pendidikanAgama;
    }
    public String getTeologiMoral() {
        return teologiMoral;
    }
    public String getKalkulus() {
        return kalkulus;
    }
    public String getStatistika() {
        return statistika;
    }
    public double getUts1() {
        return uts1;
    }
    public double getUts2() {
        return uts2;
    }
    public double getUas() {
        return uas;
    }
    
    public double calcNilaiAngka(){
        return((0.3*uts1) + (0.3*uts2) + (0.4*uas));
    }
    public char calcNilaiHuruf(){
        double nilai=calcNilaiAngka();
        if (nilai>=90 && nilai<=100){
             return('A');           
        }
        else if(nilai>=80){
            return('B');
        }
        else if(nilai>=65){
            return('C');
        }
        else if(nilai>=50){
            return('D');
        }
        else {
            return('E');
        }
    }
    
    public void printInfo1(){
        System.out.println("          Test Nilai          ");
        System.out.println("------------------------------");
    }
    public void printInfo2(){
        System.out.println("Mata Kuliah\t: " + getPbo1());
        System.out.println("Nilai UTS 1\t: " + getUts1());
        System.out.println("Nilai UTS 2\t: " + getUts2());
        System.out.println("Nilai UAS\t: " + getUas());
        System.out.println("Nilai Angka\t: " + calcNilaiAngka());
        System.out.println("Nilai Huruf\t: " + calcNilaiHuruf());
    }
}
