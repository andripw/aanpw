package testnilai;
public class TestNilai {
    public static void main(String[] args) {
        Nilai n1;
        
        n1 = new Nilai();
        n1.printInfo1();
        n1.setPbo1("Pemrograman Berorientasi Obyek I");
        n1.setUts1(80);
        n1.setUts2(90);
        n1.setUas(100);
        n1.printInfo2();
    }    
}
