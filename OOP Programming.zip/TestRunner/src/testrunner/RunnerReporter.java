package testrunner;

public interface RunnerReporter {
    public void distance(int dist);
}

