package testrunner;

public class RunnerController extends Thread implements RunnerReporter{

    private final RunnerThread[] runingRuner;
    public static int DEFAULT_RUNER = 3;
    private final int numberOfRuningRuner;

    public RunnerController(int numberOfRuner) {
        if (numberOfRuner > 1) {
            numberOfRuningRuner = numberOfRuner;
        } else {
            numberOfRuningRuner = DEFAULT_RUNER;
        }
        runingRuner = new RunnerThread[numberOfRuningRuner];
    }

    @Override
    public void run() {
        for (int i = 0; i < numberOfRuningRuner; i++) {
            runingRuner[i] = new RunnerThread();
            runingRuner[i].setRr((RunnerReporter) (this));
        }
        for (int i = 0; i < numberOfRuningRuner; i++) {
            Thread t = new Thread(runingRuner[i]);
            t.start();
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
    }

    @Override
    public void distance(int dist) {
        if (dist > 1000) {
            System.out.println("STOPPING THREAD");
            for (int i = 0; i < numberOfRuningRuner; i++) {
                runingRuner[i].setRuning(false);
            }
            System.out.println(Thread.currentThread().getName() + " WIN ");
        }
    }
}
