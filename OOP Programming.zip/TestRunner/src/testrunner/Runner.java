package testrunner;

public class Runner {

    private String name = "Andri";

    public Runner() {
        this("Andri");
    }

    public Runner(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
