package testrunner;

public class RunnerThread extends Runner implements Runnable {

    private boolean runing = true;
    private int distance = 0;
    private RunnerReporter rr;

    public void setRuning(boolean runing) {
        this.runing = runing;
    }

    public void setRr(RunnerReporter rr) {
        this.rr = rr;
    }

    @Override
    public void run() {
        while (runing) {
            //Run speed of 20-50m/s
            distance += (Math.random() * 30 + 20);
            System.out.println(toString());
            rr.distance(distance);
            try {
                Thread.sleep(300);
            } catch (InterruptedException ex) {
            }
        }
    }

    @Override
    public String toString() {
        return Thread.currentThread().getName() + " Runner Thread{" + "distance = " + distance + '}';
    }
}
