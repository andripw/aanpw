package testrunner;

public class TestRunner {

    public static void main(String[] args) {
        RunnerController a = new RunnerController(3);
        a.start();
        try {
            a.join();
        } catch (InterruptedException e) {
        }
    }

}
