package testnilaimahasiswa;
import java.util.Scanner;
class NilaiMahasiswa {
    private String nama;
    private String nim;
    private double uts1;
    private double uts2;
    private double uas;
    private int jumlahTugas=10;
    private double[] tugas;
    
    public NilaiMahasiswa(){
        nama="Andri Prasetyo Wibowo";
        nim="175314039";
        uts1=60;
        uts2=60;
        uas =0;
        tugas=new double[jumlahTugas];
    }
    public NilaiMahasiswa(String na, String ni, double u1, double u2, 
                          double ua, double[] tg, int jmlTgs){
        nama=na;
        nim=ni;
        uts1=u1;
        uts2=u2;
        uas=ua;
        tugas=tg;
        jumlahTugas=jmlTgs;
        tugas=new double[jumlahTugas];
    }
    
    public String getNama(){
        return nama;
    }
    public String getNim(){
        return nim;
    }
    public double getUts1(){
        return uts1;
    }
    public double getUts2(){
        return uts2;
    }
    public double getUas(){
        return uas;
    }
    public void setNama(String na){
        nama=na;
    }
    public void setNim(String ni){
        nim=ni;
    }
    public void setUts1(double u1){
        uts1=u1;
    }
    public void setUts2(double u2){
        uts2=u2;
    }
    public void setUas(double ua){
        uas=ua;
    }
    public void inputTugas(){
        int i;
        Scanner kbdIn;
        
        kbdIn = new Scanner(System.in);
        
        for(i=0; i<jumlahTugas; i++){
            System.out.print("Nilai Tugas ke " + i + " : ");
            tugas[i] = kbdIn.nextDouble();
        }
    }
    public double calcAverageTugas(){
        int i;
        double  sigma=0;
        for(i=0; i<10; i++){
            sigma=sigma + tugas[i];
        }
        return (sigma/10);
    }
    public double calcMax(){
        int i;
        double max;
        max=tugas[0];
        for(i=0; i<10; i++){
            if(tugas[i]>max){
                max=tugas[i];
            }
        }
        return (max);
    }
    public double calcMin(){
        int i;
        double min;
        min=tugas[0];
        for(i=0; i<10; i++){
            if(tugas[i]<min){
                min=tugas[i];
            }
        }
        return (min);
    }
    public double calcVarians(){
        int i;
        double sigma=0, rerata=sigma/10, varians;
        for(i=0; i<10; i++){
            sigma=sigma+(tugas[i]-rerata)*(tugas[i]-rerata);
        }
        varians=sigma /(10-1);
        return (varians);
    }
    public double calcStdDeviasi(){
        int i;
        double sigma=0, varians, stddev;
        for(i=0; i<10; i++){
            sigma=sigma+(tugas[i]-calcAverageTugas())*(tugas[i]-calcAverageTugas());
        }
        varians=sigma/(10-1);
        stddev=Math.sqrt(varians);
        return(stddev);
    }
    public double calcNilaiAngka(){
        return((0.3*uts1) + (0.3*uts2) + (0.3*uas) + (0.1*calcAverageTugas()));
    }
    public char calcNilaiHuruf(){
        double nilai=calcNilaiAngka();
        if (nilai>=90 && nilai<=100){
             return('A');           
        }
        else if(nilai>=80){
            return('B');
        }
        else if(nilai>=65){
            return('C');
        }
        else if(nilai>=50){
            return('D');
        }
        else {
            return('E');
        }
    }
    public boolean isRemidi(){
        double nilai=calcNilaiHuruf();
        if (uts1==0 || uts2==0 || uas==0){
            return(true);
        }
        else if(calcNilaiHuruf()=='D'||calcNilaiHuruf()=='E'){
             return(true);
        }
        else{
            return(false);
        }
    }
    public void InfoNilaiMahasiswa1(){
        System.out.printf("         Nilai Mahasiswa       \n");
        System.out.printf("-------------------------------\n");
        System.out.printf("Nama         : Edi\n");
        System.out.printf("NIM          : 165314020\n");
        System.out.printf("Nilai UTS 1  : %.2f\n", uts1);
        System.out.printf("Nilai UTS 2  : %.2f\n", uts2);
        System.out.printf("Nilai UAS    : %.2f\n", uas);
        System.out.printf("Nilai Angka  : %.2f\n", calcNilaiAngka());
        System.out.printf("Nilai Huruf  : %c\n", calcNilaiHuruf());
        System.out.printf("Nilai Maximal: %.2f\n", calcMax());
        System.out.printf("Nilai Minimal: %.2f\n", calcMin());
        System.out.printf("Varians      : %.2f\n", calcVarians());
        System.out.printf("Std Deviasi  : %.2f\n", calcStdDeviasi());
    }
    public void InfoNilaiTugas(){
        System.out.printf("Nilai Tugas  : %.2f\n", calcAverageTugas());
    }
}
