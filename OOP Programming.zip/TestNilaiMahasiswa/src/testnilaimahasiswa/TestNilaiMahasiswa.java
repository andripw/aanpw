package testnilaimahasiswa;
public class TestNilaiMahasiswa {
    public static void main(String[] args) {
        NilaiMahasiswa mhs1, mhs2;
        
        mhs1 = new NilaiMahasiswa();
        mhs1.InfoNilaiMahasiswa1();
        mhs1.inputTugas();
        System.out.printf("Nama         : %s\n", mhs1.getNama());
        System.out.printf("NIM          : %s\n", mhs1.getNim());
        System.out.printf("Nilai UTS 1  : %.2f\n", mhs1.getUts1());
        System.out.printf("Nilai UTS 2  : %.2f\n", mhs1.getUts2());
        System.out.printf("Nilai UAS    : %.2f\n", mhs1.getUas());
        System.out.printf("Nilai Angka  : %.2f\n", mhs1.calcNilaiAngka());
        System.out.printf("Nilai Huruf  : %c\n", mhs1.calcNilaiHuruf());
        System.out.printf("Nilai Tugas  : %.2f\n", mhs1.calcAverageTugas());
        System.out.printf("Nilai Maximal: %.2f\n", mhs1.calcMax());
        System.out.printf("Nilai Minimal: %.2f\n", mhs1.calcMin());
        System.out.printf("Varians      : %.2f\n", mhs1.calcVarians());
        System.out.printf("Std Deviasi  : %.2f\n", mhs1.calcStdDeviasi());
        if (mhs1.isRemidi()){
            System.out.printf("Anda Berhak Remidi\n");
        }
        else{
            System.out.printf("Anda Tidak Berhak Remidi\n");
        }
        System.out.printf("\n");
        mhs1.setNama("Edi\n");
        System.out.printf("Set Nama\n");
        System.out.printf("Nama Mahasiswa setelah di Set Nama adalah %s", mhs1.getNama());
        mhs1.setNim("165314020\n");
        System.out.printf("Set NIM\n");
        System.out.printf("Nama Mahasiswa setelah di Set NIM adalah %s", mhs1.getNim());
        mhs1.setUts1(90);
        System.out.printf("Set UTS 1\n");
        System.out.printf("Nilai Mahasiswa setelah di Set UTS 1 adalah %.2f\n", mhs1.getUts1());
        mhs1.setUts2(100);
        System.out.printf("Set UTS 2\n");
        System.out.printf("Nilai Mahasiswa setelah di Set UTS 2 adalah %.2f\n", mhs1.getUts2());
        mhs1.setUas(90);
        System.out.printf("Set UAS\n");
        System.out.printf("Nilai Mahasiswa setelah di Set UAS adalah %.2f\n", mhs1.getUas());
        System.out.printf("Nilai Angka  : %.2f\n", mhs1.calcNilaiAngka());
        System.out.printf("Nilai Huruf  : %c\n", mhs1.calcNilaiHuruf());
        System.out.printf("Nilai Tugas  : %.2f\n", mhs1.calcAverageTugas());
        System.out.printf("Nilai Maximal: %.2f\n", mhs1.calcMax());
        System.out.printf("Nilai Minimal: %.2f\n", mhs1.calcMin());
        System.out.printf("Varians      : %.2f\n", mhs1.calcVarians());
        System.out.printf("Std Deviasi  : %.2f\n", mhs1.calcStdDeviasi());
        if (mhs1.isRemidi()){
            System.out.printf("Anda Berhak Remidi\n");
        }
        else{
            System.out.printf("Anda Tidak Berhak Remidi\n");
        }
        
        mhs2 = new NilaiMahasiswa();
        mhs2.inputTugas();
        System.out.printf("\n");
        System.out.printf("Nama         : %s\n", mhs2.getNama());
        System.out.printf("NIM          : %s\n", mhs2.getNim());
        System.out.printf("Nilai UTS 1  : %.2f\n", mhs2.getUts1());
        System.out.printf("Nilai UTS 2  : %.2f\n", mhs2.getUts2());
        System.out.printf("Nilai UAS    : %.2f\n", mhs2.getUas());
        System.out.printf("Nilai Angka  : %.2f\n", mhs2.calcNilaiAngka());
        System.out.printf("Nilai Huruf  : %c\n", mhs2.calcNilaiHuruf());
        System.out.printf("Nilai Tugas  : %.2f\n", mhs2.calcAverageTugas());
        System.out.printf("Nilai Maximal: %.2f\n", mhs2.calcMax());
        System.out.printf("Nilai Minimal: %.2f\n", mhs2.calcMin());
        System.out.printf("Varians      : %.2f\n", mhs2.calcVarians());
        if (mhs2.isRemidi()){
            System.out.printf("Anda Berhak Remidi\n");
        }
        else{
            System.out.printf("Anda Tidak Berhak Remidi\n");
        }
        System.out.printf("\n");
        mhs2.setNama("Joko\n");
        System.out.printf("Set Nama\n");
        System.out.printf("Nama Mahasiswa setelah di Set Nama adalah %s", mhs2.getNama());
        mhs2.setNim("145314013\n");
        System.out.printf("Set NIM\n");
        System.out.printf("Nama Mahasiswa setelah di Set NIM adalah %s", mhs2.getNim());
        mhs2.setUts1(65);
        System.out.printf("Set UTS 1\n");
        System.out.printf("Nilai Mahasiswa setelah di Set UTS 1 adalah %.2f\n", mhs2.getUts1());
        mhs2.setUts2(70);
        System.out.printf("Set UTS 2\n");
        System.out.printf("Nilai Mahasiswa setelah di Set UTS 2 adalah %.2f\n", mhs2.getUts2());
        mhs2.setUas(80);
        System.out.printf("Set UAS\n");
        System.out.printf("Nilai Mahasiswa setelah di Set UAS adalah %.2f\n", mhs2.getUas());
        System.out.printf("Nilai Angka  : %.2f\n", mhs2.calcNilaiAngka());
        System.out.printf("Nilai Huruf  : %c\n", mhs2.calcNilaiHuruf());
        System.out.printf("Nilai Tugas  : %.2f\n", mhs2.calcAverageTugas());
        System.out.printf("Nilai Maximal: %.2f\n", mhs2.calcMax());
        System.out.printf("Nilai Minimal: %.2f\n", mhs2.calcMin());
        System.out.printf("Varians      : %.2f\n", mhs2.calcVarians());
        System.out.printf("Std Deviasi  : %.2f\n", mhs2.calcStdDeviasi());
        if (mhs2.isRemidi()){
            System.out.printf("Anda Berhak Remidi\n");
        }
        else{
            System.out.printf("Anda Tidak Berhak Remidi\n");
        }
    }
}
