package testthread3;

public class MyThread3 extends Thread {
    private int stop;
    private boolean running = true;    
// FLAG untuk Thread 'bunuh diri', selama true Thread akan hidup
// Thread tidak dapat 'dibunuh' oleh Thread lain, termasuk 'penciptanya'
// Thread yang jalan terus-menerus, harus ada mekanisme mengakhiri dirinya.
// bila FLAG dibuat static maka berlaku untuk seluruh class    
    
    public MyThread3() {
        stop = 0;
    }

    public MyThread3(int stop) {
        this.stop = stop;
    }

    public void setStop(int stop) {
        this.stop = stop;
    }
    
    public void setRunning(boolean running) {
        this.running = running;
    }

   // Override the run() method to specify the thread's running behavior    
    @Override
    public void run() {
        int i = 1;
        while  (i <= 50 && running){
            System.out.println(Thread.currentThread().getName() + ": iterasi ke" + i);
// Memanfaatkan flag untuk menghentikan Thread
// bila dibuat static, maka Thread yang se class ikut mati
            if(i == stop)
                running = false;
            i++;
        }
        
        System.out.println(Thread.currentThread().getName() + " Stoping !!!"); 
        
    }
}
