package testthread3;

public class Coordinator extends Thread{
// Thread yang banyak lebih mudah dalam bentuk array
    private final MyThread3[] worker;
    private final int number;
    
    public Coordinator(int number){
        
        if (number > 0)
            this.number = number;
        else
            this.number = 1;
// create worker array untuk n entry
        worker = new MyThread3[this.number];
    }
    
    @Override
    public void run() {

// create isi dari array slave yang berupa Object Thread
        for(int i=0; i < worker.length; i++)
            worker[i]= new MyThread3();

// set 'syarat hitup' slave[0]
        worker[0].setStop(5);

// start Thread 
        for(int i=0; i < worker.length; i++)
            worker[i].start();
//      Thread.yield();
        

/*        
        try {
            Thread.sleep(2);
            } 
        catch (InterruptedException ex) { }

// Coordinatorkan mematikan semua Slave
        for(int i=0; i < worker.length; i++)
            worker[i].setRunning(false);
*/        

        System.out.println("COORDINATOR Stopping!!!!!"); 
        
    }
}
