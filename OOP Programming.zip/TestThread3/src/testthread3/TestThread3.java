package testthread3;

public class TestThread3 {

    public static void main(String[] args) {
        Coordinator c = new Coordinator(3);
        c.start();
// Ilustrasi Thread (Coordinator) memanggil Thread lain
        System.out.println("MAIN PROGRAM Stopping!!!!!");        

    }
}
