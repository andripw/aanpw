package testtime;
public class TestTime {
    public static void main(String[] args) {
        Time t1, t2, t3;        
        
        t1 = new Time();
        try{
            t1.setSecond(0);
            t1.setMinute(0);
            t1.setHours(0);
            t1.setDay(0);
            t1.setMonth(0);
            t1.setYears(0);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
        System.out.println(t1.toString1());
        System.out.println(t1.toString2());
        System.out.println("");
        
        t2 = new Time();
        try{
            t2.setSecond(0);
            t2.setMinute(0);
            t2.setHours(22);
            t2.setMonth(9);
            t2.setDay(1);           
            t2.setYears(2008);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
        t2.previousSecond();
        t2.previousDay();
        System.out.println(t2.toString1()); 
        System.out.println(t2.toString2());
        System.out.println("");
        
        t3 = new Time();
        try{
            t3.setSecond(59);
            t3.setMinute(59);
            t3.setHours(23);
            t3.setMonth(2);
            t3.setDay(28);            
            t3.setYears(2018);
        }
        catch(Exception ex){
            System.out.println(ex);
        }
        t3.nextSecond();
        t3.nextMinute();
        t3.nextHours();
        t3.nextDay();    
        System.out.println(t3.toString1());
        System.out.println(t3.toString2());
        System.out.println("");
    }    
}
