package testtime;

public class Time {

    private int second;
    private int minute;
    private int hours;
    private int day;
    private int month;
    private int years;

    public Time() {
    }

    public Time(int second, int minute, int hours, int day, int month, int years) {
        this.second = second;
        this.minute = minute;
        this.hours = hours;
        this.day = day;
        this.month = month;
        this.years = years;
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int second) throws Exception {
        if (second >= 0 && second <= 59) {
            this.second = second;
        } else {
            throw new Exception("Error Second");
        }
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) throws Exception {
        if (minute >= 0 && minute <= 59) {
            this.minute = minute;
        } else {
            throw new Exception("Error Minute");
        }
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) throws Exception {
        if (hours >= 0 && hours <= 23) {
            this.hours = hours;
        } else {
            throw new Exception("Error Hours");
        }
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) throws Exception {
        switch (month) {
            case 2:
                if (years % 400 == 0 && years % 100 != 0 && years % 4 == 0 && day <= 28) {
                    this.day = day;
                } else if (years % 100 == 0 && day <= 27) {
                    this.day = day;
                } else if (years % 4 == 0 && day <= 28) {
                    this.day = day;
                } else {
                    throw new Exception("Error Day");
                }
                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (day <= 31) {
                    this.day = day;
                } else {
                    throw new Exception("Error Day");
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                if (day <= 30) {
                    this.day = day;
                } else {
                    throw new Exception("Error Day");
                }
                break;
            default:
                throw new Exception("Error Day");
        }
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) throws Exception {
        if (month >= 1 && month <= 12) {
            this.month = month;
        } else {
            throw new Exception("Error Month");
        }
    }

    public int getYears() {
        return years;
    }

    public void setYears(int years) throws Exception {
        if (years >= 1) {
            this.years = years;
        } else {
            throw new Exception("Error Years");
        }
    }

    public void nextSecond() {
        if (second < 59) {
            second++;
        } else {
            second = 0;
            this.nextMinute();
        }
    }

    public void nextMinute() {
        if (minute < 59) {
            minute++;
        } else {
            minute = 0;
            this.nextHours();
        }
    }

    public void nextHours() {
        if (hours < 23) {
            hours++;
        } else {
            hours = 0;
        }
    }

    public void nextDay() {
        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (day <= 30) {
                    day++;
                } else {
                    day = 1;
                    nextMonth();
                }
                break;
            case 2:
                if (years % 400 == 0) {
                    if (day > 0 && day < 29) {
                        day++;
                    } else {
                        day = 1;
                        this.nextMonth();
                    }
                } else if (years % 100 == 0) {
                    if (day > 0 && day < 28) {
                        day++;
                    } else {
                        day = 1;
                        this.nextMonth();
                    }
                } else if (years % 4 == 0) {
                    if (day > 0 && day < 29) {
                        day++;
                    } else {
                        day = 1;
                        this.nextMonth();
                    }
                } else {
                    if (day > 0 && day < 28) {
                        day++;
                    } else {
                        day = 1;
                        this.nextMonth();
                    }
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                if (day <= 29) {
                    ++day;
                } else {
                    day = 1;
                    nextMonth();
                }
                break;
            default:
        }
    }

    public void nextMonth() {
        if (month <= 12) {
            month++;
        } else {
            month = 1;
            this.nextYears();
        }
    }

    public void nextYears() {
        years++;
    }

    public void previousSecond() {
        if (second <= 59) {
            if (second == 0) {
                second = 60;
                this.previousMinute();
            }
            second--;
        } else {
            second = 0;
            this.previousMinute();
        }
    }

    public void previousMinute() {
        if (minute <= 59) {
            if (minute == 0) {
                minute = 60;
                this.previousHours();
            }
            minute--;
        } else {
            minute = 0;
            this.previousHours();
        }
    }

    public void previousHours() {
        if (hours <= 23) {
            hours--;
        } else {
            hours = 0;
        }
    }

    public void previousDay() {
        switch (month) {
            case 5:
            case 7:
            case 10:
            case 12:
                if (day > 1) {
                    day--;
                } else {
                    day = 30;
                    previousMonth();
                }
                break;
            case 3:
                if (years % 400 == 0 && years % 100 == 0 && years % 4 == 0) {
                    day = 29;
                    previousMonth();
                } else {
                    day = 28;
                    previousMonth();
                }
                break;
            case 1:
            case 2:
            case 4:
            case 6:
            case 8:
            case 9:
            case 11:
                if (day > 1) {
                    day--;
                } else {
                    day = 31;
                    previousMonth();
                }

        }
    }

    public void previousMonth() {
        if (month > 0 && month <= 12) {
            if (month == 1) {
                month = 13;
            }
            month--;
        } else {
            month = 12;
            this.previousYears();
        }
    }

    public void previousYears() {
        years--;
    }

    public String toString2() {
        return "Date\t" + " " + day + " - " + month + " - " + years;
    }

    public String toString1() {
        return "Time\t" + " " + second + " : " + minute + " : " + hours;
    }
}
