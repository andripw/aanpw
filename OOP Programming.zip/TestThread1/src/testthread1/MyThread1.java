package testthread1;

public class MyThread1 extends Thread{
    private int x;
 
    public MyThread1() {
        x = 5;
    }

    public void setX(int x) {
        this.x = x;
    }
 
   // Override the run() method to specify the thread's running behavior
    @Override
    public void run() {
        for (int i = 1; i <= x; ++i)
            System.out.println(Thread.currentThread().getName() + ": iterasi ke" + i);
        System.out.println(Thread.currentThread().getName() + " Stoping !!!");    

    }    
}
