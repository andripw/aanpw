package projectsdl;

public class Antrian {

    LinkedListOb antrian;

    public Antrian() {
        antrian = new LinkedListOb();
    }

    public void enqueue(Object x) {
        antrian.addLast(x);
    }

    public Object dequeue() {
        return antrian.removeFirst();
    }

    public Object size() {
        return antrian.getSize();
    }

    public boolean isEmpety() {
        return antrian.isEmpty();
    }

    public void cetak() {
        antrian.print();
    }

    public ListNodeOb search(Object x) {
        return antrian.search(x);
    }
}
