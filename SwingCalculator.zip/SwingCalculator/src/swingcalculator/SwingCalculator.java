package swingcalculator;

public class SwingCalculator {

    public static void main(String[] args) {
        Calculator calculator = new Calculator();
    }   
}
