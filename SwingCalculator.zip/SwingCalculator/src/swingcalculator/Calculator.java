package swingcalculator;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class Calculator extends JFrame implements ActionListener {

    private final int MAX_INPUT_LENGTH = 50;
    private final int INPUT_MODE = 0;
    private final int RESULT_MODE = 1;
    private final int ERROR_MODE = 2;
    private int displayMode;
    private boolean clearOnNextDigit, percent;
    private double lastNumber;
    private String lastOperator;
    private static final int FRAME_WIDTH = 350;
    private static final int FRAME_HEIGHT = 240;
    private static final int FRAME_X_ORIGIN = 400;
    private static final int FRAME_Y_ORIGIN = 250;
    private final JMenu menuFile, menuHelp;
    private final JMenuItem menuitemExit, menuitemAbout;
    private final JButton btnNumbers[];
    private final JPanel panelButtons, panelMaster, panelBackSpace, panelControl;
    private final JTextArea taDisplay;

    public Calculator() {
        this.setTitle("Calculator");
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);
        this.setResizable(false);

        Font area = new Font("Times New Roman", 1, 26);

        Panel panelDisplay = new Panel(new FlowLayout());
        taDisplay = new JTextArea(1, 20);
        taDisplay.setEditable(false);
        taDisplay.setColumns(30);
        taDisplay.setFont(area);
        panelDisplay.add(taDisplay);

        Font f14 = new Font("Arial", 1, 14);

        menuFile = new JMenu("File");
        menuitemExit = new JMenuItem("Exit");
        menuFile.add(menuitemExit);

        menuHelp = new JMenu("Help");
        menuitemAbout = new JMenuItem("About Calculator");
        menuHelp.add(menuitemAbout);

        JMenuBar menuBar = new JMenuBar();
        menuBar.add(menuFile);
        menuBar.add(menuHelp);
        setJMenuBar(menuBar);

        setBackground(Color.gray);
        Container contentPane = getContentPane();
        
        panelMaster = new JPanel();
        setLayout(new BorderLayout());
        add(panelDisplay, BorderLayout.NORTH);
        getContentPane().add(taDisplay, BorderLayout.NORTH);

        btnNumbers = new JButton[23];
        panelButtons = new JPanel();
        for (int i = 0; i <= 9; i++) {
            btnNumbers[i] = new JButton(String.valueOf(i));
        }
        btnNumbers[10] = new JButton("+/-");
        btnNumbers[11] = new JButton(".");
        btnNumbers[12] = new JButton("=");
        btnNumbers[13] = new JButton("/");
        btnNumbers[14] = new JButton("*");
        btnNumbers[15] = new JButton("-");
        btnNumbers[16] = new JButton("+");
        btnNumbers[17] = new JButton("Sqrt");
        btnNumbers[18] = new JButton("x^2");
        btnNumbers[19] = new JButton("%");

        panelBackSpace = new JPanel();
        panelBackSpace.setLayout(new GridLayout(1, 1, 2, 2));

        btnNumbers[20] = new JButton("Backspace");
        panelBackSpace.add(btnNumbers[20]);

        panelControl = new JPanel();
        panelControl.setLayout(new GridLayout(1, 2, 2, 2));

        btnNumbers[21] = new JButton(" CE ");
        btnNumbers[22] = new JButton("C");

        panelControl.add(btnNumbers[21]);
        panelControl.add(btnNumbers[22]);

        for (int i = 0; i < btnNumbers.length; i++) {
            btnNumbers[i].setFont(f14);
            if (i < 10) {
                btnNumbers[i].setForeground(Color.BLACK);
            } else {
                btnNumbers[i].setForeground(Color.red);
            }
        }

        panelButtons.setLayout(new GridLayout(4, 5, 2, 2));

        for (int i = 7; i <= 9; i++) {
            panelButtons.add(btnNumbers[i]);
        }
        // add button and sqrt
        panelButtons.add(btnNumbers[13]);
        panelButtons.add(btnNumbers[17]);

        // Baris kedua
        for (int i = 4; i <= 6; i++) {
            panelButtons.add(btnNumbers[i]);
        }

        // add button * and x^2
        panelButtons.add(btnNumbers[14]);
        panelButtons.add(btnNumbers[18]);

        // Baris ketiga
        for (int i = 1; i <= 3; i++) {
            panelButtons.add(btnNumbers[i]);
        }

        //adds button and %
        panelButtons.add(btnNumbers[15]);
        panelButtons.add(btnNumbers[19]);

        //Baris keempat
        // add 0, +/-, ., +, =     
        panelButtons.add(btnNumbers[10]);
        panelButtons.add(btnNumbers[0]);
        panelButtons.add(btnNumbers[11]);
        panelButtons.add(btnNumbers[16]);
        panelButtons.add(btnNumbers[12]);

        panelMaster.setLayout(new BorderLayout());
        panelMaster.add(panelBackSpace, BorderLayout.WEST);
        panelMaster.add(panelControl, BorderLayout.EAST);
        panelMaster.add(panelButtons, BorderLayout.SOUTH);

        // Add components to frame
        getContentPane().add(panelMaster, BorderLayout.SOUTH);

        for (int i = 0; i < btnNumbers.length; i++) {
            btnNumbers[i].addActionListener(this);
        }

        menuitemAbout.addActionListener(this);
        menuitemExit.addActionListener(this);

        this.clearAll();

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public void setDisplayString(String s) {
        taDisplay.setText(s);
    }

    public String getDisplayString() {
        return taDisplay.getText();
    }

    public void addDecimalPoint() {
        displayMode = INPUT_MODE;
        if (clearOnNextDigit) {
            setDisplayString("");
        }
        String inputString = getDisplayString();
        if (inputString.indexOf(".") < 0) {
            setDisplayString(new String(inputString + "."));
        }
    }

    public void processSignChange() {
        if (displayMode == INPUT_MODE) {
            String input = getDisplayString();
            if (input.length() > 0 && !input.equals("0")) {
                if (input.indexOf("-") == 0) {
                    setDisplayString(input.substring(1));
                } else {
                    setDisplayString("-" + input);
                }
            }
        } else if (displayMode == RESULT_MODE) {
            double numberInDisplay = getNumberInDisplay();
            if (numberInDisplay != 0) {
                displayResult(-numberInDisplay);
            }
        }
    }

    public void clearAll() {
        setDisplayString("0");
        lastOperator = "0";
        lastNumber = 0;
        displayMode = INPUT_MODE;
        clearOnNextDigit = true;
    }

    public void clearExisting() {
        setDisplayString("0");
        clearOnNextDigit = true;
        displayMode = INPUT_MODE;
    }

    public double getNumberInDisplay() {
        String input = taDisplay.getText();
        return Double.parseDouble(input);
    }

    public void processOperator(String op) {
        if (displayMode != ERROR_MODE) {
            double numberInDisplay = getNumberInDisplay();
            if (!lastOperator.equals("0")) {
                try {
                    double result = processLastOperator();
                    displayResult(result);
                    lastNumber = result;
                } catch (Exception e) {
                }
            } else {
                lastNumber = numberInDisplay;
            }
            clearOnNextDigit = true;
            lastOperator = op;
        }
    }

    public void processEquals() {
        double result = 0;
        if (displayMode != ERROR_MODE) {
            try {
                result = processLastOperator();
                displayResult(result);
            } catch (Exception e) {
                displayError("Cannot divide by zero!");
            }
            lastOperator = "0";
        }
    }

    public double processLastOperator() throws Exception {
        double result = 0;
        double numberInDisplay = getNumberInDisplay();
        if (lastOperator.equals("/")) {
            if (numberInDisplay == 0) {
                throw new Exception();
            }
            result = lastNumber / numberInDisplay;
        }
        if (lastOperator.equals("*")) {
            result = lastNumber * numberInDisplay;
        }
        if (lastOperator.equals("-")) {
            result = lastNumber - numberInDisplay;
        }
        if (lastOperator.equals("+")) {
            result = lastNumber + numberInDisplay;
        }
        if (lastOperator.equals("x^2")) {
            result = lastNumber * lastNumber;
        }
        return result;
    }

    public void displayResult(double result) {
        setDisplayString(Double.toString(result));
        lastNumber = result;
        displayMode = RESULT_MODE;
        clearOnNextDigit = true;
    }

    public void displayError(String errorMessage) {
        setDisplayString(errorMessage);
        lastNumber = 0;
        displayMode = ERROR_MODE;
        clearOnNextDigit = true;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        double result = 0;
        if (ae.getSource() == menuitemExit) {
            System.exit(0);
        } else if (ae.getSource() == menuitemAbout) {
            JOptionPane.showMessageDialog(this, "Version 1.0\nBy Andri PW");
        }
        for (int i = 0; i < btnNumbers.length; i++) {
            if (ae.getSource() == btnNumbers[i]) {
                switch (i) {
                    case 0:
                        addDigitToDisplay(i);
                        break;
                    case 1:
                        addDigitToDisplay(i);
                        break;
                    case 2:
                        addDigitToDisplay(i);
                        break;
                    case 3:
                        addDigitToDisplay(i);
                        break;
                    case 4:
                        addDigitToDisplay(i);
                        break;
                    case 5:
                        addDigitToDisplay(i);
                        break;
                    case 6:
                        addDigitToDisplay(i);
                        break;
                    case 7:
                        addDigitToDisplay(i);
                        break;
                    case 8:
                        addDigitToDisplay(i);
                        break;
                    case 9:
                        addDigitToDisplay(i);
                        break;
                    case 10:	// +/-
                        processSignChange();
                        break;
                    case 11:	// decimal point
                        addDecimalPoint();
                        break;
                    case 12:	// =
                        processEquals();
                        break;
                    case 13:	// divide
                        processOperator("/");
                        break;
                    case 14:	// *
                        processOperator("*");
                        break;
                    case 15:	// -
                        processOperator("-");
                        break;
                    case 16:	// +
                        processOperator("+");
                        break;
                    case 17:	// sqrt
                        if (displayMode != ERROR_MODE) {
                            try {
                                if (getDisplayString().indexOf("-") == 0) {
                                    displayError("Invalid input for function!");
                                }
                                result = Math.sqrt(getNumberInDisplay());
                                displayResult(result);
                            } catch (Exception ex) {
                                displayError("Invalid input for function!");
                                displayMode = ERROR_MODE;
                            }
                        }
                        break;
                    case 18:	// ^2
                        if (displayMode != ERROR_MODE) {
                            try {
                                if (getNumberInDisplay() == 0) {
                                    displayError("Cannot divide by zero!");
                                }
                                result = getNumberInDisplay() * getNumberInDisplay();
                                displayResult(result);
                            } catch (Exception e) {
                                displayError("Cannot divide by zero!");
                                displayMode = ERROR_MODE;
                            }
                        }
                        break;
                    case 19:	// %
                        if (displayMode != ERROR_MODE) {
                            try {
                                result = getNumberInDisplay() / 100;
                                displayResult(result);
                            } catch (Exception ex) {
                                displayError("Invalid input for function!");
                                displayMode = ERROR_MODE;
                            }
                        }
                        break;
                    case 20:	// backspace
                        if (displayMode != ERROR_MODE) {
                            setDisplayString(getDisplayString().substring(0,
                                    getDisplayString().length() - 1));
                            if (getDisplayString().length() < 1) {
                                setDisplayString("0");
                            }
                        }
                        break;
                    case 21:	// CE
                        clearExisting();
                        break;
                    case 22:	// C
                        clearAll();
                        break;
                }
            }
        }
    }

    public void addDigitToDisplay(int digit) {
        if (clearOnNextDigit) {
            setDisplayString("");
        }
        String inputString = getDisplayString();
        if (inputString.indexOf("0") == 0) {
            inputString = inputString.substring(1);
        }
        if ((!inputString.equals("0") || digit > 0) && inputString.length() < MAX_INPUT_LENGTH) {
            setDisplayString(inputString + digit);
        }
        displayMode = INPUT_MODE;
        clearOnNextDigit = false;
    }
}
