package objectdoublelinklist;

import java.util.NoSuchElementException;

public class LinkedListObject {

    private ListNodeObject head;
    private int size;

    public LinkedListObject() {
        this.head = new ListNodeObject();
        this.head.next = head;
        this.head.prev = head;
        this.size = 0;
    }

    public ListNodeObject addBefore(Object o, ListNodeObject bantu) {
        ListNodeObject baru = new ListNodeObject(o);
        baru.next = bantu;
        baru.prev = bantu.prev;
        bantu.prev.next = baru;
        bantu.prev = baru;
        this.size++;
        return baru;
    }

    public void addFirst(Object o) {
        this.addBefore(o, head.next);
    }

    public void addLast(Object o) {
        this.addBefore(o, head);
    }

    public Object removeFirst() {
        return remove(head.next);
    }

    public Object removeLast() {
        return remove(head.prev);
    }

    public boolean isEmpty() {
        if (head.next == head) {
            return true;
        } else {
            return false;
        }
    }

    public void printInfo() {
        ListNodeObject bantu = head.next;
        while (bantu != head) {
            System.out.print(" " + bantu.getElemen());
            bantu = bantu.getNext();
        }
    }

    public ListNodeObject search(Object o) {
        ListNodeObject bantu = head.next;
        while (bantu != head) {
            if (((Comparable) bantu.elemen).compareTo(o) == 0) {
                return bantu;
            }
            bantu = bantu.getNext();
        }
        return null;
    }

    @Override
    public String toString() {
        return "LinkedList{" + "head=" + head + ", size=" + size + '}';
    }

    public Object remove(ListNodeObject bantu) {
        if (isEmpty() || bantu == null) {
            throw new NoSuchElementException();
        } else {
            bantu.prev.next = bantu.next;
            bantu.next.prev = bantu.prev;
            bantu.next = null;
            bantu.prev = null;
            return bantu;
        }
    }
}
