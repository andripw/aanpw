package objectdoublelinklist;

import name.Mahasiswa;

public class ListNodeObject {

    Object elemen;
    ListNodeObject next;
    ListNodeObject prev;

    public ListNodeObject() {
        this.next = null;
        this.prev = null;
    }

    public ListNodeObject(Object o) {
        this.elemen = o;
        this.next = null;
        this.prev = null;
    }

    public ListNodeObject(Object elemen, ListNodeObject next, ListNodeObject prev) {
        this.elemen = elemen;
        this.next = next;
        this.prev = prev;
    }

    public Object getElemen() {
        return elemen;
    }

    public void setElemen(Object elemen) {
        this.elemen = elemen;
    }

    public ListNodeObject getNext() {
        return next;
    }

    public void setNext(ListNodeObject next) {
        this.next = next;
    }

    public ListNodeObject getPrev() {
        return prev;
    }

    public void setPrev(ListNodeObject prev) {
        this.prev = prev;
    }
}
