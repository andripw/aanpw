package test;

import name.Arrays;

public class MainBinary {

    public static void main(String[] args) {
        int[] data = {1, 2, 5, 6, 10};
        int kunci = 5;

        int hasil = Arrays.binarySearch(data, kunci);
        if (hasil >= 0) {
            System.out.println("Data " + kunci + " berhasil ditemukan di index ke-" + hasil);
        } else {
            System.out.println("Data " + kunci + " tidak ditemukan");
        }
    }
}
