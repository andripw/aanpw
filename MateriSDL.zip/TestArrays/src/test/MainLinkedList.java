package test;

import name.*;

public class MainLinkedList {

    public static void main(String[] args) {
        LinkedList senarai = new LinkedList();
        senarai.addFirst(3);
        senarai.addFirst(5);
        senarai.addLast(8);

        System.out.println("Isi senarai : ");
        senarai.printInfo();

        /*
        senarai.removeFirst();
        senarai.removeLast();
        System.out.println("Isi senarai setelah dihapus : ");
        senarai.printInfo();*/
        
        int cari = 8;
        ListNode simpan = senarai.search(cari);
        System.out.println("Data yang dicari : " + cari);
        if (simpan != null) {
            System.out.println("Data " + simpan.getData() + " ditemukan didalam ListNode");
        } else {
            System.out.println("Data tidak ditemukan didalam ListNode");
        }
    }
}
