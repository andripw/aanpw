package test;

import name.Arrays;

public class MainBubleSortASC {

    public static void main(String[] args) {
        int[] data = {48, 37, 12, 33, 86, 33};

        System.out.println("Isi larik : ");
        Arrays.cetak(data);
        System.out.println("");

        Arrays.bubleSortASC(data);

        System.out.println("Isi larik data setelah diurutkan : ");
        Arrays.cetak(data);
        System.out.println("");
    }
}
