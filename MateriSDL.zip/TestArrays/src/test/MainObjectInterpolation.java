package test;

import name.*;

public class MainObjectInterpolation {

    public static void main(String[] args) {
        Mahasiswa mhs[] = new Mahasiswa[3];

        mhs[0] = new Mahasiswa(100, "Adi");
        mhs[1] = new Mahasiswa(200, "Bambang");
        mhs[2] = new Mahasiswa(300, "Eko");

        Arrays.insertionSortASC(mhs);
        Mahasiswa mhsCari = new Mahasiswa(100, "Adi");
        int hasil = Arrays.interpolationSearch(mhs, mhsCari);
        if (hasil >= 0) {
            System.out.println("Data Mahasiswa ditemukan di index ke-" + hasil);
        } else {
            System.out.println("Data Mahasiswa tidak ditemukan");
        }
    }
}
