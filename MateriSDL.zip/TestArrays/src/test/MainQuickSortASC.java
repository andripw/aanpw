package test;

import name.*;

public class MainQuickSortASC {

    public static void main(String[] args) {
        int[] data = {23, 45, 12, 24, 56, 34};
        System.out.println("Isi data : ");
        Arrays.cetak(data);
        System.out.println("");
        Arrays.quickSortASC(data);
        System.out.println("Isi data setelah diurutkan : ");
        Arrays.cetak(data);
        System.out.println("");
    }
}
