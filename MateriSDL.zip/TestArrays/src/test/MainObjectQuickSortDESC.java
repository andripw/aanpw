package test;

import name.*;

public class MainObjectQuickSortDESC {

    public static void main(String[] args) {
        Mahasiswa mhs[] = new Mahasiswa[3];
        mhs[0] = new Mahasiswa();
        mhs[0].setNim(400);
        mhs[0].setNama("Agung");
        mhs[1] = new Mahasiswa();
        mhs[1].setNim(100);
        mhs[1].setNama("Andri");
        mhs[2] = new Mahasiswa();
        mhs[2].setNim(500);
        mhs[2].setNama("Eko");

        System.out.print("Data mahasiswa : ");
        Arrays.cetak(mhs);
        Arrays.quickSortDESC(mhs);
        System.out.printf("\n\nData mahasiswa setelah diurutkan : ");
        Arrays.cetak(mhs);
    }
}
