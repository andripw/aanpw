package test;

import name.*;

public class MainObjectBubleDESC {

    public static void main(String[] args) {
        Mahasiswa mhs[] = new Mahasiswa[3];

        mhs[0] = new Mahasiswa();
        mhs[0].setNim(200);
        mhs[0].setNama("Agung");
        mhs[1] = new Mahasiswa();
        mhs[1].setNim(100);
        mhs[1].setNama("Andri");
        mhs[2] = new Mahasiswa();
        mhs[2].setNim(500);
        mhs[2].setNama("Eko");

        Arrays.cetak(mhs);
        
        Arrays.bubleSortDESC(mhs);
        System.out.println("");
        System.out.printf("\nData mahasiswa setelah diurutkan : \n");
        Arrays.cetak(mhs);
    }
}
