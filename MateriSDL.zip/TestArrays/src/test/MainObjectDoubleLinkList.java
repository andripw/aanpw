package test;

import java.util.NoSuchElementException;
import name.Mahasiswa;
import objectdoublelinklist.*;

public class MainObjectDoubleLinkList {

    public static void main(String[] args) {
        Mahasiswa mhs[] = new Mahasiswa[3];
        mhs[0] = new Mahasiswa(175314001, "Edi");
        mhs[1] = new Mahasiswa(175314003, "Andri");
        mhs[2] = new Mahasiswa(175314005, "Eko");

        LinkedListObject senarai = new LinkedListObject();
        senarai.addFirst(mhs[0]);
        senarai.addFirst(mhs[1]);
        senarai.addLast(mhs[2]);
        System.out.print("Isi senarai : ");
        senarai.printInfo();
        
        try{
            senarai.removeLast();
            System.out.print("\nIsi senarai setelah dihapus : ");
            senarai.printInfo();
        }catch(NoSuchElementException e){
            System.err.printf("\nException : %s\n", e);
            System.out.println("Senarai kosong, tidak ada yang dihapus\n");
        }
        
        Object cari = mhs[0];
        ListNodeObject simpan = senarai.search(cari);
        System.out.println("\nData yang dicari : " + cari);
        if (simpan != null) {
            System.out.println("Data " + simpan.getElemen() + " \nditemukan didalam ListNode");
        } else {
            System.out.println("Data tidak ditemukan didalam ListNode");
        }
    }
}
