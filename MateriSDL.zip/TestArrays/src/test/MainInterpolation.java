package test;

import java.util.Random;
import name.Arrays;

public class MainInterpolation {

    public static void main(String[] args) {
//        int[] data = {1, 2, 5, 6, 10};
        Random data = new Random();
        int a[];
        a = new int[1000];
        for (int i = 0; i < a.length; i++) {
            System.out.print(data.nextInt(1000) + ",");
        }
        /*
        int kunci = 0;

        int hasil = Arrays.interpolationSearch(data, kunci);
        if (hasil >= 0) {
            System.out.println("Data " + kunci + " berhasil ditemukan di index ke-" + hasil);
        } else {
            System.out.println("Data " + kunci + " tidak ditemukan");
        }*/
    }
}
