package test;

import name.*;

public class MainObjectBinary {

    public static void main(String[] args) {
        Mahasiswa mhs[] = new Mahasiswa[3];

        mhs[0] = new Mahasiswa(100, "Adi");
        mhs[1] = new Mahasiswa(200, "Bambang");
        mhs[2] = new Mahasiswa(300, "Eko");

        Mahasiswa mhsCari = new Mahasiswa(123, "Joko");
        int hasil;
        hasil = Arrays.binarySearch(mhs, mhsCari);
        if (hasil == 0) {
            System.out.println("Data mahasiswa ditemukan di index ke-" + hasil);
        } else {
            System.out.println("Data mahasiswa tidak ditemukan");
        }
    }
}
