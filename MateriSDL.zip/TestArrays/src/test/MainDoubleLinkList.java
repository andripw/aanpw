package test;

import doublelinklist.*;
import java.util.NoSuchElementException;

public class MainDoubleLinkList {

    public static void main(String[] args) {
        LinkedList senarai = new LinkedList();
        senarai.addFirst(3);
        senarai.addFirst(5);
        senarai.addLast(8);

        System.out.print("Isi senarai : ");
        senarai.printInfo();
        
        try{
            senarai.removeFirst();
            System.out.print("\nIsi senarai setelah dihapus : ");
            senarai.printInfo();
        }catch(NoSuchElementException e){
            System.err.printf("\nException : %s\n", e);
            System.out.println("Senarai kosong, tidak ada yang dihapus\n");
        }
        
        int cari = 3;
        ListNode simpan = senarai.search(cari);
        System.out.println("\nData yang dicari : " + cari);
        if (simpan != null) {
            System.out.println("Data " + simpan.getElemen() + " ditemukan didalam ListNode");
        } else {
            System.out.println("Data tidak ditemukan didalam ListNode");
        }
    }
}
