package test;

import name.*;

public class MainSequential {

    public static void main(String[] args) {
        int[] data = {1, 2, 5, 6, 10};
        int kunci = 10;

        int hasil = Arrays.sequentialSearch(data, kunci);
        if (hasil >= 0) {
            System.out.println("Data " + kunci + " berhasil ditemukan");
        } else {
            System.out.println("Data " + kunci + " tidak ditemukan");
        }
    }
}
