package test;

import name.Arrays;
import name.Mahasiswa;

public class MainObjectSequential {

    public static void main(String[] args) {
        Mahasiswa mhs[] = new Mahasiswa[3];

        mhs[0] = new Mahasiswa(100, "Adi");
        mhs[1] = new Mahasiswa(200, "Bambang");
        mhs[2] = new Mahasiswa(300, "Eko");

        Arrays.insertionSortASC(mhs);
        Mahasiswa mhsCari = new Mahasiswa(10, "Joko");
        int hasil;
        hasil = Arrays.sequentialSearch(mhs, mhsCari);
        if (hasil == 0) {
            System.out.println("Data Mahasiswa ditemukan di index ke-" + hasil);
        } else {
            System.out.println("Data Mahasiswa tidak ditemukan");
        }
    }
}
