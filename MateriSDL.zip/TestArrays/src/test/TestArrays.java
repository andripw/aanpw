package test;

import name.Arrays;

public class TestArrays {
    
    public static void main(String[] args) {
        int array[] = {12, 25, 33, 37, 48, 57, 86, 92};
        int x = 25;
        System.out.printf("%s%8s\n", "Index", "Value");
        Arrays.cetak(array);
        Arrays.cetak(args);
    }
}
