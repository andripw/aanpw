package name;

public class Arrays {

    public static void cetak(int x[]) {
        for (int i = 0; i < x.length; i++) {
            System.out.print("  " + x[i]);
        }
    }

    public static void cetak(Object o[]) {
        for (int i = 0; i < o.length; i++) {
            System.out.print("       " + o[i]);
        }
    }

    public static int sequentialSearch(int[] data, int kunci) {
        for (int i = 0; i < data.length; i++) {
            if (kunci == data[i]) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(int[] data, int kunci) {
        int indexAwal = 0;
        int indexAkhir = data.length - 1;

        while (indexAwal <= indexAkhir) {
            int indexTengah = (indexAwal + indexAkhir) / 2;
            if (data[indexTengah] == kunci) {
                return indexTengah;
            } else {
                if (data[indexTengah] > kunci) {
                    indexAkhir = indexTengah - 1;
                } else {
                    indexAwal = indexTengah + 1;
                }
            }
        }
        return -1;
    }

    public static int interpolationSearch(int[] data, int kunci) {
        int indexAwal = 0;
        int indexAkhir = data.length - 1;

        while (indexAwal <= indexAkhir) {
            int indexTengah = indexAwal + ((kunci - data[indexAwal]) * (indexAkhir - indexAwal))
                    / (data[indexAkhir] - data[indexAwal]);
            if (data[indexTengah] == kunci) {
                return indexTengah;
            } else {
                if (data[indexTengah] > kunci) {
                    indexAkhir = indexTengah - 1;
                } else {
                    indexAwal = indexTengah + 1;
                }
            }
        }
        return -1;
    }

    public static int sequentialSearch(Object[] data, Object kunci) {
        for (int i = 0; i < data.length; i++) {
            if (((Comparable) kunci).compareTo(data[i]) == 0) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(Object[] data, Object kunci) {
        int indexAwal = 0;
        int indexAkhir = data.length - 1;

        while (indexAwal <= indexAkhir) {
            int indexTengah = (indexAwal + indexAkhir) / 2;
            if (((Comparable) kunci).compareTo(data[indexTengah]) == 0) {
                return indexTengah;
            } else {
                if (((Comparable) kunci).compareTo(data[indexTengah]) > 1) {
                    indexAkhir = indexTengah - 1;
                } else {
                    indexAwal = indexTengah + 1;
                }
            }
        }
        return -1;
    }

    public static int interpolationSearch(Object[] data, Object kunci) {
        int indexAwal = 0;
        int indexAkhir = data.length - 1;

        while (indexAwal <= indexAkhir) {
            int indexTengah = indexAwal
                    + ((((Mahasiswa) kunci).getNim() - ((Mahasiswa) data[indexAwal]).getNim()) * ((indexAkhir - indexAwal)))
                    / (((Mahasiswa) data[indexAkhir]).getNim() - ((Mahasiswa) data[indexAwal]).getNim());
            if (((Comparable) data[indexTengah]).compareTo(kunci) == 0) {
                return indexTengah;
            } else {
                if (((Comparable) data[indexTengah]).compareTo(kunci) > 0) {
                    indexAkhir = indexTengah - 1;
                } else {
                    indexAwal = indexTengah + 1;
                }
            }
        }
        return -1;
    }

    /*
     Algoritma buble sort
     Algoritma ini digunakan untuk mengurutkan data dengan metode bubble sort.
     Masukan berupa kumpulan data dalam larik.
     Keluaran akan menghasilkan kumpulan data dalam larik yang sudah dalam keadaan urut.
     Langkah 0	: Baca data ke dalam larik 
     Langkah 1	: Untuk iterasi = 1 sampai N-1 lakukan langkah 2 
     Langkah 2	: Untuk elemen = 0 sampai N-1-iterasi lakukan langkah 3
     Langkah 3	: Test apakah larik[elemen] > larik[elemen + 1]
     Jika ya, tukarkan nilai kedua elemen ini
     */
    public static void bubleSortASC(int[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = 0; elemen <= kunci.length - 1 - iterasi; elemen++) {
                if (kunci[elemen] > kunci[elemen + 1]) {
                    int temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen + 1];
                    kunci[elemen + 1] = temp;
                }
            }
        }
    }

    public static void bubleSortDESC(int[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = 0; elemen <= kunci.length - 1 - iterasi; elemen++) {
                if (kunci[elemen] < kunci[elemen + 1]) {
                    int temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen + 1];
                    kunci[elemen + 1] = temp;
                }
            }
        }
    }

    /*
     Algoritma selection sort
     Algoritma ini digunakan untuk mengurutkan data dengan metode selection sort.
     Masukan berupa kumpulan data dalam larik.
     Keluaran akan menghasilkan kumpulan data dalam larik yang sudah dalam keadaan urut.
     Langkah 0	: Baca data ke dalam larik 
     Langkah 1	: Untuk iterasi = 0 sampai N-2 lakukan langkah 2 sampai 5 
     Langkah 2	: Tentukan minIndex = iterasi; 
     Langkah 3	: Untuk elemen = iterasi + 1 sampai N-1 lakukan langkah 4
     Langkah 4	: Test apakah larik[elemen] < larik[minIndex ]
     Jika ya, minIndex = elemen
     Langkah 5	: Tukarkan nilai larik[iterasi] dengan larik[minIndex]
     */
    public static void selectionSortASC(int[] kunci) {
        for (int iterasi = 0; iterasi <= kunci.length - 2; iterasi++) {
            int minIndex = iterasi;
            for (int elemen = iterasi + 1; elemen <= kunci.length - 1; elemen++) {
                if (kunci[elemen] < kunci[minIndex]) {
                    minIndex = elemen;
                }
            }
            int temp = kunci[iterasi];
            kunci[iterasi] = kunci[minIndex];
            kunci[minIndex] = temp;
        }
    }

    public static void selectionSortDESC(int[] kunci) {
        for (int iterasi = 0; iterasi <= kunci.length - 2; iterasi++) {
            int minIndex = iterasi;
            for (int elemen = iterasi + 1; elemen <= kunci.length - 1; elemen++) {
                if (kunci[elemen] > kunci[minIndex]) {
                    minIndex = elemen;
                }
            }
            int temp = kunci[iterasi];
            kunci[iterasi] = kunci[minIndex];
            kunci[minIndex] = temp;
        }
    }

    /*
     Algoritma insertion sort
     Algoritma ini digunakan untuk mengurutkan data dengan metode insertion sort.
     Masukan berupa kumpulan data dalam larik.
     Keluaran akan menghasilkan kumpulan data dalam larik yang sudah dalam keadaan urut.
     Langkah 0	: Baca data ke dalam larik 
     Langkah 1	: Untuk iterasi = 1 sampai N-1 lakukan langkah 2
     Langkah 2	: Untuk elemen = iterasi sampai 1 lakukan langkah 3
     Langkah 3	: Test apakah larik[elemen] < larik[elemen-1]
     Jika ya, tukarkan nilai larik[elemen] dengan larik[elemen-1]
     */
    public static void insertionSortASC(int[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = iterasi; elemen >= 1; elemen--) {
                if (kunci[elemen] < kunci[elemen - 1]) {
                    int temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen - 1];
                    kunci[elemen - 1] = temp;
                }
            }
        }
    }

    public static void insertionSortDESC(int[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = iterasi; elemen >= 1; elemen--) {
                if (kunci[elemen] > kunci[elemen - 1]) {
                    int temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen - 1];
                    kunci[elemen - 1] = temp;
                }
            }
        }
    }

    public static void bubleSortASC(Object[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = 0; elemen <= kunci.length - 1 - iterasi; elemen++) {
                if (((Comparable) kunci[elemen]).compareTo(kunci[elemen + 1]) >= 0) {
                    Object temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen + 1];
                    kunci[elemen + 1] = temp;
                }
            }
        }
    }

    public static void bubleSortDESC(Object[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = 0; elemen <= kunci.length - 1 - iterasi; elemen++) {
                if (((Comparable) kunci[elemen]).compareTo(kunci[elemen + 1]) < 0) {
                    Object temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen + 1];
                    kunci[elemen + 1] = temp;
                }
            }
        }
    }

    public static void selectionSortASC(Object[] kunci) {
        for (int iterasi = 0; iterasi <= kunci.length - 2; iterasi++) {
            int minIndex = iterasi;
            for (int elemen = iterasi + 1; elemen <= kunci.length - 1; elemen++) {
                if (((Comparable) kunci[elemen]).compareTo(kunci[minIndex]) < 0) {
                    minIndex = elemen;
                }
            }
            Object temp = kunci[iterasi];
            kunci[iterasi] = kunci[minIndex];
            kunci[minIndex] = temp;
        }
    }

    public static void selectionSortDESC(Object[] kunci) {
        for (int iterasi = 0; iterasi <= kunci.length - 2; iterasi++) {
            int minIndex = iterasi;
            for (int elemen = iterasi + 1; elemen <= kunci.length - 1; elemen++) {
                if (((Comparable) kunci[elemen]).compareTo(kunci[minIndex]) > 0) {
                    minIndex = elemen;
                }
            }
            Object temp = kunci[iterasi];
            kunci[iterasi] = kunci[minIndex];
            kunci[minIndex] = temp;
        }
    }

    public static void insertionSortASC(Object[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = iterasi; elemen >= 1; elemen--) {
                if (((Comparable) kunci[elemen]).compareTo(kunci[elemen - 1]) < 0) {
                    Object temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen - 1];
                    kunci[elemen - 1] = temp;
                }
            }
        }
    }

    public static void insertionSortDESC(Object[] kunci) {
        for (int iterasi = 1; iterasi <= kunci.length - 1; iterasi++) {
            for (int elemen = iterasi; elemen >= 1; elemen--) {
                if (((Comparable) kunci[elemen]).compareTo(kunci[elemen - 1]) > 0) {
                    Object temp = kunci[elemen];
                    kunci[elemen] = kunci[elemen - 1];
                    kunci[elemen - 1] = temp;
                }
            }
        }
    }

    public void swap(Object[] o, int a, int b) {
        Object temp = o[a];
        o[a] = o[b];
        o[b] = temp;
    }

    /*
    Test apakah indek awal< akhir
		Jika ya, kerjakan langkah-langkah sebagai berikut:
    Langkah 1:	Tentukan i = awal+1; j = akhir.
    Langkah 2:	Tambahkan nilai i dengan 1 selama i <= akhir dan x[i] <= x[awal].
                (Bergerak dari kiri ke kanan).
    Langkah 3:	Kurangi nilai j dengan 1 selama j > awal  dan x[j] > x[awal].
                (Bergerak dari kanan ke kiri).
    Langkah 4:	Kerjakan langkah 5 sampai 7 selama i < j.
    Langkah 5:	Tukarkan nilai x[i] dengan x[j].
    Langkah 6:	Tambahkan nilai i dengan 1 selama i <= akhir dan x[i] <= x[awal].
                (Bergerak dari kiri ke kanan).
    Langkah 7:	Kurangi nilai j dengan 1 selama j > awal  dan x[j] > x[awal].
                (Bergerak dari kanan ke kiri).
    Langkah 8:	Tukarkan nilai x[awal] dengan x[j].
    Langkah 9:	Panggil fungsi QuickSort rekursif dengan parameter indek awal = awal dan indek akhir = j-1.
    Langkah 10:	Panggil fungsi QuickSort rekursif dengan parameter indek awal = j+1 dan indek akhir = akhir.
    Langkah 11:	Selesai. 
    */
    public static void quickSortASC(int[] data, int awal, int akhir) {
        if (awal < akhir) {
            int i = awal + 1;
            int j = akhir;
            while (i < akhir && data[i] <= data[awal]) {
                i++;
            }
            while (j > awal && data[j] > data[awal]) {
                j--;
            }
            while (i < j) {
                int temp = data[i];
                data[i] = data[j];
                data[j] = temp;
                while (i <= akhir && data[i] <= data[awal]) {
                    i++;
                }
                while (j > awal && data[j] > data[awal]) {
                    j--;
                }
            }
            int temp = data[awal];
            data[awal] = data[j];
            data[j] = temp;

            Arrays.quickSortASC(data, awal, j - 1);
            Arrays.quickSortASC(data, j + 1, akhir);
        }
    }

    public static void quickSortASC(int[] data) {
        Arrays.quickSortASC(data, 0, data.length - 1);
    }

    public static void quickSortDESC(int[] data, int awal, int akhir) {
        if (awal < akhir) {
            int i = awal + 1;
            int j = akhir;
            while (i < akhir && data[i] >= data[awal]) {
                i++;
            }
            while (j > awal && data[j] < data[awal]) {
                j--;
            }
            while (i < j) {
                int temp = data[i];
                data[i] = data[j];
                data[j] = temp;
                while (i <= akhir && data[i] >= data[awal]) {
                    i++;
                }
                while (j > awal && data[j] < data[awal]) {
                    j--;
                }
            }
            int temp = data[awal];
            data[awal] = data[j];
            data[j] = temp;

            Arrays.quickSortDESC(data, awal, j - 1);
            Arrays.quickSortDESC(data, j + 1, akhir);
        }
    }

    public static void quickSortDESC(int[] data) {
        Arrays.quickSortDESC(data, 0, data.length - 1);
    }
    
    public static void quickSortASC(Object[] data, int awal, int akhir){
        if (((Comparable) awal).compareTo(akhir) < 0) {
            int i = awal + 1;
            int j = akhir;
            while (i < akhir && (((Comparable) data[i]).compareTo(data[awal]) < 0)) {
                i++;
            }
            while (j > awal && (((Comparable) data[j]).compareTo(data[awal]) > 0)) {
                j--;
            }
            while (i < j) {
                Object temp = data[i];
                data[i] = data[j];
                data[j] = temp;
                while (i <= akhir && (((Comparable) data[i]).compareTo(data[awal]) < 0)) {
                    i++;
                }
                while (j > awal && (((Comparable) data[j]).compareTo(data[awal]) > 0)) {
                    j--;
                }
            }
            Object temp = data[awal];
            data[awal] = data[j];
            data[j] = temp;

            Arrays.quickSortASC(data, awal, j - 1);
            Arrays.quickSortASC(data, j + 1, akhir);
        }
    }
    
    public static void quickSortAsc(Object[] data){
        Arrays.quickSortASC(data, 0, data.length - 1);
    }
    
    public static void quickSortDESC(Object[] data, int awal, int akhir){
        if (awal < akhir) {
            int i = awal + 1;
            int j = akhir;
            while (i <= akhir && (((Comparable) data[i]).compareTo(data[awal]) >= 0)) {
                i++;
            }
            while (j > awal && (((Comparable) data[j]).compareTo(data[awal]) < 0)) {
                j--;
            }
            while (i < j) {
                Object temp = data[i];
                data[i] = data[j];
                data[j] = temp;
                while (i <= akhir && (((Comparable) data[i]).compareTo(data[awal]) >= 0)) {
                    i++;
                }
                while (j > awal && (((Comparable) data[j]).compareTo(data[awal]) < 0)) {
                    j--;
                }
            }
            Object temp = data[awal];
            data[awal] = data[j];
            data[j] = temp;

            Arrays.quickSortDESC(data, awal, j - 1);
            Arrays.quickSortDESC(data, j + 1, akhir);
        }
    }
    
    public static void quickSortDESC(Object[] data){
        Arrays.quickSortDESC(data, 0, data.length - 1);
    }
    
    
}
