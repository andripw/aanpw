package name;

public class Mahasiswa implements Comparable {

    private int nim;
    private String nama;

    public Mahasiswa(int nim, String nama) {
        this.nim = nim;
        this.nama = nama;
    }

    public Mahasiswa(int nim) {
        this.nim = nim;
    }

    public Mahasiswa(String nama) {
        this.nama = nama;
    }

    public Mahasiswa() {

    }

    public int getNim() {
        return nim;
    }

    public void setNim(int nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public static void cetak(Object x[]) {
        for (int i = 0; i < x.length; i++) {
            System.out.println(i + "       " + x[i]);
        }
    }

    @Override
    public String toString() {
        return "\nNIM\t= " + nim + "\nNama\t= " + nama;
    }

    @Override
    public int compareTo(Object k) {
        if (nim == ((Mahasiswa) k).getNim()) {
            return 0;
        } else if (nim > ((Mahasiswa) k).getNim()) {
            return 1;
        } else {
            return -1;
        }
    }
//    @Override
//    public int compareTo(Object o) {
//        return nama.compareTo(((Mahasiswa) o).getNama());
//        }

}
