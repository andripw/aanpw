package name;

public class LinkedList {

    private ListNode firstNode;
    private ListNode lastNode;
    private String nama;

    public LinkedList() {
        this.firstNode = null;
        this.lastNode = null;
    }

    public LinkedList(String nama) {
        this.nama = nama;
    }

    public void addFirst(int x) {
        ListNode baru = new ListNode(x);
        if (isEmpty()) {
            this.firstNode = baru;
            this.lastNode = baru;
        } else {
            baru.setNext(this.firstNode);
            this.firstNode = baru;
        }
    }

    public void addLast(int x) {
        ListNode baru = new ListNode(x);
        if (isEmpty()) {
            this.firstNode = baru;
            this.lastNode = baru;
        } else {
            this.lastNode.setNext(baru);
            this.lastNode = baru;
        }
    }

    public ListNode removeFirst() {
        if (isEmpty()) {
            return null;
        } else if (this.firstNode == this.lastNode) {
            ListNode bantu = this.firstNode;
            this.lastNode = this.firstNode = null;
            return bantu;
        } else {
            ListNode bantu = this.firstNode;
            this.firstNode = firstNode.getNext();
            return bantu;
        }
    }

    public ListNode removeLast() {
        if (isEmpty()) {
            return null;
        } else if (this.firstNode == this.lastNode) {
            ListNode bantu = this.firstNode;
            this.lastNode = this.firstNode = null;
            return bantu;
        } else {
            ListNode bantu = this.firstNode;
            while (bantu.getNext() != this.lastNode) {
                bantu = bantu.getNext();
            }
            this.lastNode = bantu;
            bantu = this.lastNode.getNext();
            this.lastNode.getNext();
            this.lastNode.setNext(null);
            return bantu;
        }
    }

    public boolean isEmpty() {
        if (firstNode == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "LinkedList{" + "firstNode=" + firstNode + ", lastNode=" + lastNode + ", nama=" + nama + '}';
    }

    public void printInfo() {
        ListNode bantu = this.firstNode;
        while (bantu != null) {
            System.out.println(bantu.getData());
            bantu = bantu.getNext();
        }
    }

    public ListNode search(int x) {
        ListNode baru = this.firstNode;
        while (baru != null) {
            if (baru.getData() == x) {
                return baru;
            }
            baru = baru.getNext();
        }
        return baru;
    }
}
