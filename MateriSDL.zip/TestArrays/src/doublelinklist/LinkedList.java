package doublelinklist;

import java.util.NoSuchElementException;

public class LinkedList {

    private ListNode head;
    private int size;

    public LinkedList() {
        this.head = new ListNode();
        this.head.next = head;
        this.head.prev = head;
        this.size = 0;
    }

    public ListNode addBefore(int x, ListNode bantu) {
        ListNode baru = new ListNode(x);
        baru.next = bantu;
        baru.prev = bantu.prev;
        bantu.prev.next = baru;
        bantu.prev = baru;
        this.size++;
        return baru;
    }

    public void addFirst(int x) {
        this.addBefore(x, head.next);
    }

    public void addLast(int x) {
        this.addBefore(x, head);
    }

    public ListNode removeFirst() {
        return remove(head.next);
    }

    public ListNode removeLast() {
        return remove(head.prev);
    }

    public boolean isEmpty() {
        if (head.next == head) {
            return true;
        } else {
            return false;
        }
    }

    public void printInfo() {
        ListNode bantu = head.next;
        while (bantu != head) {
            System.out.print(" " + bantu.getElemen());
            bantu = bantu.getNext();
        }
    }

    public ListNode search(int x) {
        ListNode bantu = head.next;
        while (bantu != head) {
            if (bantu.elemen == x) {
                return bantu;
            }
            bantu = bantu.getNext();
        }
        return null;
    }

    @Override
    public String toString() {
        return "LinkedList{" + "head=" + head + ", size=" + size + '}';
    }

    public ListNode remove(ListNode bantu) {
        if (isEmpty() || bantu == null) {
            throw new NoSuchElementException();
        } else {
            bantu.prev.next = bantu.next;
            bantu.next.prev = bantu.prev;
            bantu.next = null;
            bantu.prev = null;
            return bantu;
        }
    }
}
